const DEFAULTS = {
  settings: {
    delivery: "qbit",
    torrentClient: "qbit",
    qbitHost: "http://localhost:8080",
    qbitUser: "",
    qbitPass: "",
    qbitCategory: "tv",
    preferredQualities: ["1080p", "720p"],
    preferredUploaders: ["MeGusta", "TGx", "EZTV"],
    rssSources: [],
    minSeeders: 0,
    autoCheckMinutes: 0
  },
  shows: [],
  meta: { fullScanCount: 0, lastSeasonDateCheck: "" },
  uploaderRanks: {
    megusta: 1,
    grace: 2,
    elite: 3,
    flux: 4,
    skyfire: 5,
    syncopy: 6,
    kandi: 7,
    ntb: 8
  }
};

const EZTV_APIS = ["https://eztvx.to/api", "https://eztv.re/api", "https://eztv.wf/api"];
const EZTV_RSS_FEEDS = ["https://eztvx.to/ezrss.xml", "https://eztv.re/ezrss.xml", "https://eztv.wf/ezrss.xml"];
const FETCH_TIMEOUT_MS = 12000;
const SCAN_CACHE_TTL_MS = 120000;
let recentScanCache = null;
let recentScanCacheKey = "";
let recentScanCacheTime = 0;

chrome.runtime.onInstalled.addListener(async () => {
  const state = await chrome.storage.local.get(["settings", "shows", "uploaderRanks", "meta"]);
  if (!state.settings) await chrome.storage.local.set({ settings: DEFAULTS.settings });
  if (!state.shows) await chrome.storage.local.set({ shows: DEFAULTS.shows });
  if (!state.uploaderRanks) await chrome.storage.local.set({ uploaderRanks: DEFAULTS.uploaderRanks });
  if (!state.meta) await chrome.storage.local.set({ meta: DEFAULTS.meta });
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== "auto-check") return;
  await scanAllShows({ autoSend: true });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    try {
      if (message.type === "get-state") {
        sendResponse({ ok: true, ...(await getState()) });
      } else if (message.type === "save-settings") {
        sendResponse(await saveSettings(message.settings));
      } else if (message.type === "add-show") {
        sendResponse(await addShow(message.show));
      } else if (message.type === "remove-show") {
        sendResponse(await removeShow(message.id));
      } else if (message.type === "set-show-enabled") {
        sendResponse(await setShowEnabled(message.id, message.enabled));
      } else if (message.type === "scan-all") {
        sendResponse(await scanAllShows({ autoSend: false }));
      } else if (message.type === "check-season-dates") {
        sendResponse(await checkSeasonDates({ force: true }));
      } else if (message.type === "maybe-check-season-dates") {
        sendResponse(await maybeCheckSeasonDates());
      } else if (message.type === "scan-show") {
        sendResponse(await scanOneShow(message.id));
      } else if (message.type === "send-magnet") {
        await sendMagnet(message.magnet);
        sendResponse({ ok: true });
      } else if (message.type === "send-magnets") {
        sendResponse(await sendMagnets(message.items || []));
      } else if (message.type === "mark-seen") {
        sendResponse(await markSeen(message.id, message.code));
      } else if (message.type === "qbit-test") {
        sendResponse(await torrentClientTest());
      } else if (message.type === "open-settings") {
        await chrome.tabs.create({ url: chrome.runtime.getURL("popup.html#settings") });
        sendResponse({ ok: true });
      } else {
        sendResponse({ ok: false, error: "Unknown action." });
      }
    } catch (error) {
      sendResponse({ ok: false, error: error.message || String(error) });
    }
  })();
  return true;
});

async function saveSettings(nextSettings) {
  const { settings } = await getState();
  const merged = { ...settings, ...nextSettings };
  merged.preferredQualities = listFromText(merged.preferredQualities);
  merged.preferredUploaders = listFromText(merged.preferredUploaders);
  merged.rssSources = rssSourcesFromValue(merged.rssSources);
  merged.minSeeders = Number(merged.minSeeders) || 0;
  merged.autoCheckMinutes = Number(merged.autoCheckMinutes) || 0;
  const permission = await ensureRequiredHostPermissions(merged);
  if (!permission.ok) return permission;
  await chrome.storage.local.set({ settings: merged });

  await chrome.alarms.clear("auto-check");
  if (merged.autoCheckMinutes >= 15) {
    await chrome.alarms.create("auto-check", { periodInMinutes: merged.autoCheckMinutes });
  }
  return { ok: true };
}

async function ensureRequiredHostPermissions(settings) {
  const origins = [];
  if (settings.delivery !== "magnet") {
    const origin = permissionOrigin(settings.qbitHost);
    if (!origin) return { ok: false, error: "Enter a valid WebUI URL before saving." };
    origins.push(origin);
  }
  for (const source of settings.rssSources || []) {
    const origin = permissionOrigin(source.url);
    if (!origin) return { ok: false, error: `Check this RSS feed URL: ${source.url}` };
    origins.push(origin);
  }
  const needed = [...new Set(origins)].filter((origin) => !isBuiltInOrigin(origin));
  if (!needed.length) return { ok: true };
  const granted = await chrome.permissions.contains({ origins: needed });
  return granted
    ? { ok: true }
    : { ok: false, error: "WebUI/RSS permission is missing. Open the extension popup Settings, save the WebUI/RSS address, and approve the browser permission prompt." };
}

function permissionOrigin(value) {
  try {
    const url = new URL(value);
    if (!/^https?:$/.test(url.protocol)) return "";
    return `${url.protocol}//${url.host}/*`;
  } catch {
    return "";
  }
}

function isBuiltInOrigin(origin) {
  return [
    "http://localhost/*",
    "http://127.0.0.1/*",
    "https://api.tvmaze.com/*",
    "https://eztvx.to/*",
    "https://eztv.re/*",
    "https://eztv.wf/*",
    "https://eztv.ag/*",
    "https://eztv.it/*",
    "https://eztv.ch/*",
    "https://eztv.li/*"
  ].includes(origin);
}

async function addShow(show) {
  const { shows } = await getState();
  const parsedInput = parseShowInput(show.name || "");
  const name = parsedInput.name;
  if (!name) return { ok: false, error: "Show name is required." };
  const targetSeason = show.targetSeason || parsedInput.targetSeason || null;
  const lastSeen = normalizeEpisode(show.lastSeen || parsedInput.lastSeen || seasonBaseline(targetSeason));
  const preferredQuality = normalizeQuality(show.preferredQuality || parsedInput.preferredQuality || "");
  const existing = shows.find((entry) =>
    compactShowNameKey(entry.name) === compactShowNameKey(name)
    && String(entry.targetSeason || "") === String(targetSeason || "")
  );
  if (existing) {
    existing.name = name;
    existing.targetSeason = targetSeason;
    if (lastSeen) {
      if (!existing.lastSeen || compareCodes(lastSeen, existing.lastSeen) > 0) {
        existing.lastSeen = lastSeen;
      }
      existing.results = pruneResultsAfter(existing.results || [], existing.lastSeen);
    }
    if (preferredQuality) existing.preferredQuality = preferredQuality;
    if (show.imdbId) existing.imdbId = cleanImdb(show.imdbId);
    sortShows(shows);
    await chrome.storage.local.set({ shows });
    return { ok: true, show: existing, updated: true };
  }
  const next = {
    id: crypto.randomUUID(),
    name,
    imdbId: cleanImdb(show.imdbId || ""),
    lastSeen,
    targetSeason,
    preferredQuality,
    baselineMode: lastSeen ? "episode" : "latest",
    enabled: true,
    results: [],
    lastChecked: "",
    skipUntil: "",
    skipReason: "",
    tvmazeId: ""
  };
  shows.push(next);
  sortShows(shows);
  await chrome.storage.local.set({ shows });
  return { ok: true, show: next };
}

async function removeShow(id) {
  const { shows } = await getState();
  await chrome.storage.local.set({ shows: shows.filter((show) => show.id !== id) });
  return { ok: true };
}

async function setShowEnabled(id, enabled) {
  const { shows } = await getState();
  const show = shows.find((entry) => entry.id === id);
  if (!show) return { ok: false, error: "Show not found." };
  show.enabled = Boolean(enabled);
  await chrome.storage.local.set({ shows });
  return { ok: true, show };
}

async function scanOneShow(id) {
  const { settings, shows } = await getState();
  const show = shows.find((entry) => entry.id === id);
  if (!show) return { ok: false, error: "Show not found." };
  if (isEndedStatus(show.seriesStatus)) {
    show.lastChecked = new Date().toISOString();
    await chrome.storage.local.set({ shows });
    return {
      ok: true,
      show,
      results: [],
      skipped: true,
      seriesStatus: show.seriesStatus,
      skipReason: `TVMaze status: ${show.seriesStatus}`
    };
  }
  if (isShowSkipped(show)) {
    show.lastChecked = new Date().toISOString();
    await chrome.storage.local.set({ shows });
    return { ok: true, show, results: [], skipped: true, skipUntil: show.skipUntil, skipReason: show.skipReason || "" };
  }
  const results = await scanShow(show, settings);
  if (results.length) show.results = results;
  show.lastChecked = new Date().toISOString();
  await chrome.storage.local.set({ shows });
  return { ok: true, show, results, keptExisting: !results.length && Boolean((show.results || []).length) };
}

async function markSeen(id, code) {
  const { shows } = await getState();
  const show = shows.find((entry) => entry.id === id);
  if (!show) return { ok: false, error: "Show not found." };
  if (code) {
    const nextSeen = normalizeEpisode(code);
    if (!show.lastSeen || compareCodes(nextSeen, show.lastSeen) > 0) {
      show.lastSeen = nextSeen;
    }
    show.results = (show.results || []).filter((item) => compareCodes(item.code, show.lastSeen) > 0);
  }
  await chrome.storage.local.set({ shows });
  return { ok: true, show };
}

async function maybeCheckSeasonDates() {
  const state = await getState();
  const meta = { ...DEFAULTS.meta, ...(state.meta || {}) };
  meta.fullScanCount = Number(meta.fullScanCount || 0) + 1;
  await chrome.storage.local.set({ meta });
  if (meta.fullScanCount % 10 !== 0) {
    return { ok: true, ran: false, fullScanCount: meta.fullScanCount, nextIn: 10 - (meta.fullScanCount % 10) };
  }
  return checkSeasonDates({ force: false, meta });
}

async function checkSeasonDates({ force, meta = null } = {}) {
  const { shows } = await getState();
  const enabledShows = shows.filter((show) => show.enabled !== false);
  const summary = { ok: true, checked: 0, updated: 0, cleared: 0, skippedUntil: [], endedShows: [], errors: [], force: Boolean(force) };
  for (const show of enabledShows) {
    try {
      summary.checked += 1;
      const result = await updateShowSeasonDate(show);
      if (result.updated) summary.updated += 1;
      if (result.cleared) summary.cleared += 1;
      if (isShowSkipped(show)) summary.skippedUntil.push(`${show.name}: ${show.skipUntil}`);
      if (isEndedStatus(show.seriesStatus)) {
        summary.endedShows.push({ id: show.id, name: show.name, status: show.seriesStatus });
      }
    } catch (error) {
      summary.errors.push(`${show.name}: ${error.message || error}`);
    }
  }
  const nextMeta = { ...DEFAULTS.meta, ...(meta || (await getState()).meta || {}) };
  nextMeta.lastSeasonDateCheck = todayIsoDate();
  await chrome.storage.local.set({ shows, meta: nextMeta });
  summary.shows = shows;
  return summary;
}

async function updateShowSeasonDate(show) {
  const before = show.skipUntil || "";
  const meta = await lookupShowMeta(show.name);
  if (meta.imdbId) show.imdbId = meta.imdbId;
  if (meta.tvmazeId) show.tvmazeId = meta.tvmazeId;
  show.seriesStatus = meta.status || show.seriesStatus || "";
  show.seasonDateChecked = todayIsoDate();
  if (!meta.tvmazeId) return { updated: false, cleared: false };
  const seasonPause = await findSeasonPause(show, meta.tvmazeId, meta.status);
  if (seasonPause && seasonPause.skipUntil) {
    show.skipUntil = seasonPause.skipUntil;
    show.skipReason = seasonPause.reason || "";
    return { updated: show.skipUntil !== before, cleared: false };
  }
  const cleared = Boolean(show.skipUntil);
  show.skipUntil = "";
  show.skipReason = "";
  return { updated: false, cleared };
}

async function findSeasonPause(show, tvmazeId, status) {
  const response = await fetchWithTimeout(`https://api.tvmaze.com/shows/${encodeURIComponent(tvmazeId)}/episodes?specials=1`);
  if (!response.ok) throw new Error(`TVMaze episodes failed: ${response.status}`);
  const episodes = await response.json();
  if (!Array.isArray(episodes)) return null;
  const last = parseCode(show.lastSeen);
  const today = todayIsoDate();
  const normalized = episodes
    .map((episode) => ({
      season: Number(episode.season || 0),
      episode: Number(episode.number || 0),
      code: `S${String(Number(episode.season || 0)).padStart(2, "0")}E${String(Number(episode.number || 0)).padStart(2, "0")}`,
      airdate: episode.airdate || ""
    }))
    .filter((episode) => episode.season && episode.episode && episode.airdate);
  const futureAfterLast = normalized
    .filter((episode) => episode.airdate >= today)
    .filter((episode) => !show.targetSeason || episode.season === Number(show.targetSeason))
    .filter((episode) => !last || compareCodes(episode.code, last.code) > 0)
    .sort((a, b) => a.airdate.localeCompare(b.airdate) || compareCodes(a.code, b.code));
  const newSeason = futureAfterLast.find((episode) => isBetweenSeasonStart(show, last, episode));
  if (newSeason) {
    return {
      skipUntil: newSeason.airdate,
      reason: `${newSeason.code} new season starts ${newSeason.airdate}`
    };
  }
  if (futureAfterLast.length) return null;
  if (isEndedStatus(status) || !last) return null;
  const latestAired = normalized
    .filter((episode) => episode.airdate < today)
    .filter((episode) => !show.targetSeason || episode.season === Number(show.targetSeason))
    .sort((a, b) => compareCodes(b.code, a.code))[0];
  if (!latestAired || compareCodes(latestAired.code, last.code) > 0) return null;
  const recheckDate = addDaysIso(today, 7);
  return {
    skipUntil: recheckDate,
    reason: `Between seasons; next season date unknown. Recheck ${recheckDate}`
  };
}

function isBetweenSeasonStart(show, last, episode) {
  if (!episode || episode.episode !== 1) return false;
  const targetSeason = Number(show.targetSeason || 0);
  if (targetSeason) {
    if (episode.season !== targetSeason) return false;
    return !last || episode.season > last.s || (episode.season === last.s && last.e === 0);
  }
  if (!last) return false;
  return episode.season > last.s;
}

function isShowSkipped(show) {
  return Boolean(show.skipUntil && show.skipUntil > todayIsoDate());
}

function isEndedStatus(status) {
  return /ended|cancelled|canceled/i.test(String(status || ""));
}

async function scanAllShows({ autoSend }) {
  const { settings, shows } = await getState();
  const enabledShows = shows.filter((show) => show.enabled !== false);
  const summary = { ok: true, checked: 0, found: 0, sent: 0, errors: [] };
  const scanCache = await prepareScanCache(settings);

  for (const show of enabledShows) {
    try {
      summary.checked += 1;
      if (isEndedStatus(show.seriesStatus)) {
        summary.ended = (summary.ended || 0) + 1;
        show.lastChecked = new Date().toISOString();
        continue;
      }
      if (isShowSkipped(show)) {
        summary.skipped = (summary.skipped || 0) + 1;
        show.lastChecked = new Date().toISOString();
        continue;
      }
      const results = await scanShow(show, settings, scanCache);
      if (results.length) show.results = results;
      show.lastChecked = new Date().toISOString();
      summary.found += results.length;
      if (autoSend) {
        const best = results[0];
        if (best) {
          await sendMagnet(best.magnet);
          const nextSeen = normalizeEpisode(best.code);
          if (nextSeen && (!show.lastSeen || compareCodes(nextSeen, show.lastSeen) > 0)) {
            show.lastSeen = nextSeen;
          }
          show.results = pruneResultsAfter(show.results || [], show.lastSeen);
          summary.sent += 1;
        }
      }
    } catch (error) {
      summary.errors.push(`${show.name}: ${error.message || error}`);
    }
  }

  await chrome.storage.local.set({ shows });
  summary.shows = shows;
  return summary;
}

async function sendMagnets(items) {
  const summary = { ok: true, sent: 0, errors: [] };
  const { shows } = await getState();
  for (const item of items) {
    try {
      await sendMagnet(item.magnet);
      summary.sent += 1;
      const show = shows.find((entry) => entry.id === item.showId);
      if (show && item.code) {
        const nextSeen = normalizeEpisode(item.code);
        if (!show.lastSeen || compareCodes(nextSeen, show.lastSeen) > 0) {
          show.lastSeen = nextSeen;
        }
        show.results = (show.results || []).filter((result) => compareCodes(result.code, show.lastSeen) > 0);
      }
    } catch (error) {
      summary.errors.push(`${item.title || item.code || "magnet"}: ${error.message || error}`);
    }
  }
  await chrome.storage.local.set({ shows });
  return summary;
}

async function prepareScanCache(settings, { force = false } = {}) {
  const cacheKey = JSON.stringify(rssSourcesFromValue(settings.rssSources));
  if (
    !force &&
    recentScanCache &&
    recentScanCacheKey === cacheKey &&
    Date.now() - recentScanCacheTime < SCAN_CACHE_TTL_MS
  ) {
    return recentScanCache;
  }
  const [builtInRssRows, customRows, uploaderRanks] = await Promise.all([
    fetchBuiltInEztvRss(),
    fetchCustomRssSources(settings),
    getUploaderRanks()
  ]);
  recentScanCache = { builtInRssRows, customRows, uploaderRanks };
  recentScanCacheKey = cacheKey;
  recentScanCacheTime = Date.now();
  return recentScanCache;
}

async function scanShow(show, settings, scanCache = null) {
  const cache = scanCache || await prepareScanCache(settings);
  let imdbId = cleanImdb(show.imdbId || "");
  if (!imdbId) {
    const exactMeta = await lookupShowMeta(show.name);
    const exactImdbId = exactMeta.imdbId;
    if (exactMeta.tvmazeId) show.tvmazeId = exactMeta.tvmazeId;
    if (exactMeta.status) show.seriesStatus = exactMeta.status;
    if (exactImdbId) {
      imdbId = exactImdbId;
      show.imdbId = imdbId;
    }
  }

  const builtInRssRows = cache.builtInRssRows || [];
  const customRows = cache.customRows || [];
  if (!imdbId && !builtInRssRows.length && !customRows.length) throw new Error("Could not resolve IMDB id.");
  let apiRows = [];
  if (imdbId) {
    try {
      apiRows = await fetchEztv(imdbId);
    } catch (error) {
      if (!builtInRssRows.length && !customRows.length) throw error;
    }
  }
  const rows = [
    ...apiRows,
    ...builtInRssRows,
    ...customRows
  ];
  const uploaderRanks = cache.uploaderRanks || await getUploaderRanks();
  const last = parseCode(show.lastSeen);
  let matches = rows
    .map(normalizeTorrent)
    .filter((item) => item.magnet && item.code)
    .filter((item) => titleMatchesShow(show.name, item.title))
    .filter((item) => !show.targetSeason || item.season === Number(show.targetSeason))
    .filter((item) => !last || compareCodes(item.code, last.code) > 0)
    .filter((item) => Number(item.seeds || 0) >= Number(settings.minSeeders || 0))
    .sort((a, b) => rank(a, show, settings, uploaderRanks) - rank(b, show, settings, uploaderRanks));
  if (!last && !show.targetSeason && show.baselineMode === "latest") {
    matches = latestPerShow(matches);
  }
  return dedupeBy(matches, (item) => item.code).slice(0, 20);
}

async function lookupImdb(showName) {
  const meta = await lookupShowMeta(showName);
  return meta.imdbId || "";
}

async function lookupShowMeta(showName) {
  const stripped = showName.replace(/\s*\([^)]+\)\s*$/, "").replace(/\s+(19|20)\d{2}\b/g, "");
  const words = normalizeShowName(stripped).split(/\s+/).filter(Boolean);
  const variants = [
    showName,
    stripped,
    normalizeShowName(stripped),
    words.length > 1 && words.every((word) => word.length === 1) ? words.join(".") : "",
    words.length > 1 && words.every((word) => word.length === 1) ? `${words.join(".")}.` : ""
  ].map((value) => String(value || "").trim()).filter(Boolean);
  for (const name of [...new Set(variants)]) {
    const url = `https://api.tvmaze.com/search/shows?q=${encodeURIComponent(name)}`;
    const response = await fetchWithTimeout(url);
    if (response.status === 404) continue;
    if (!response.ok) continue;
    const data = await response.json();
    const matches = Array.isArray(data) ? data.map((item) => item.show).filter(Boolean) : [];
    const exact = matches.find((candidate) => tvmazeTitleMatches(showName, candidate));
    const imdb = exact?.externals?.imdb || "";
    if (exact) return { imdbId: cleanImdb(imdb), tvmazeId: String(exact.id || ""), name: exact.name || showName, status: exact.status || "" };
  }
  return { imdbId: "", tvmazeId: "", name: showName, status: "" };
}

async function fetchWithTimeout(url, options = {}, timeoutMs = FETCH_TIMEOUT_MS) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...options, signal: options.signal || controller.signal });
  } finally {
    clearTimeout(timeout);
  }
}

async function fetchEztv(imdbId) {
  let lastError = "No EZTV mirror responded.";
  let sawSuccessfulMirror = false;
  for (const base of EZTV_APIS) {
    try {
      const out = [];
      const seen = new Set();
      for (let page = 1; page <= 20; page += 1) {
        const url = `${base}/get-torrents?imdb_id=${encodeURIComponent(imdbId)}&limit=100&page=${page}`;
        const response = await fetchWithTimeout(url);
        if (!response.ok) {
          lastError = `${base} returned ${response.status}`;
          break;
        }
        const data = await response.json();
        const torrents = data.torrents || [];
        for (const torrent of torrents) {
          const key = torrent.hash || torrent.torrent_url || torrent.magnet_url || torrent.title;
          if (key && seen.has(key)) continue;
          if (key) seen.add(key);
          out.push(torrent);
        }
        if (torrents.length < 100) break;
      }
      sawSuccessfulMirror = true;
      if (out.length) return out;
    } catch (error) {
      lastError = error.message || String(error);
    }
  }
  if (sawSuccessfulMirror) return [];
  throw new Error(lastError);
}

async function fetchCustomRssSources(settings) {
  const sources = rssSourcesFromValue(settings.rssSources);
  if (!sources.length) return [];
  const rows = [];
  for (const source of sources) {
    try {
      const response = await fetchWithTimeout(source.url);
      if (!response.ok) continue;
      const text = await response.text();
      rows.push(...parseRssTorrents(text, source));
    } catch {}
  }
  return rows;
}

async function fetchBuiltInEztvRss() {
  const rows = [];
  const seen = new Set();
  for (const url of EZTV_RSS_FEEDS) {
    try {
      const response = await fetchWithTimeout(url);
      if (!response.ok) continue;
      const text = await response.text();
      for (const row of parseRssTorrents(text, { name: "EZTV RSS", url })) {
        const key = row.magnet_url || row.torrent_url || row.title;
        if (key && seen.has(key)) continue;
        if (key) seen.add(key);
        rows.push(row);
      }
    } catch {}
  }
  return rows;
}

function parseRssTorrents(xmlText, source) {
  const items = String(xmlText || "").match(/<item\b[\s\S]*?<\/item>/gi) || [];
  return items.map((item) => {
    const title = firstRssValue(item, "title");
    const link = firstRssValue(item, "link");
    const enclosure = firstAttr(item, "enclosure", "url");
    const magnetUri = firstRssValue(item, "torrent:magnetURI");
    const torrentUrlValue = firstRssValue(item, "torrent:downloadUrl");
    const magnet = [magnetUri, link, enclosure].find((value) => /^magnet:/i.test(value)) || "";
    const torrentUrl = [torrentUrlValue, enclosure, link].find((value) => /^https?:\/\//i.test(value)) || "";
    const seeds = Number(firstRssValue(item, "torrent:seeds") || firstRssValue(item, "seeds") || 0) || 0;
    return {
      title,
      magnet_url: magnet,
      torrent_url: torrentUrl,
      seeds,
      source: source.name || source.url
    };
  }).filter((item) => item.title && (item.magnet_url || item.torrent_url));
}

function firstRssValue(item, tagName) {
  const escaped = tagName.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const match = String(item || "").match(new RegExp(`<${escaped}\\b[^>]*>([\\s\\S]*?)<\\/${escaped}>`, "i"));
  return decodeRssValue(match?.[1] || "");
}

function firstAttr(item, tagName, attrName) {
  const escapedTag = tagName.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const escapedAttr = attrName.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const tag = String(item || "").match(new RegExp(`<${escapedTag}\\b[^>]*>`, "i"))?.[0] || "";
  const match = tag.match(new RegExp(`${escapedAttr}=["']([^"']+)["']`, "i"));
  return decodeRssValue(match?.[1] || "");
}

function decodeRssValue(value) {
  return String(value || "")
    .replace(/^<!\[CDATA\[([\s\S]*)\]\]>$/i, "$1")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, "\"")
    .replace(/&#39;/g, "'")
    .trim();
}

async function sendMagnet(magnet) {
  const { settings } = await getState();
  if (settings.delivery === "magnet") {
    await openMagnetLocally(magnet);
    return;
  }
  const permission = await ensureRequiredHostPermissions(settings);
  if (!permission.ok) throw new Error(permission.error);
  await torrentClientAdd(magnet, settings);
}

async function openMagnetLocally(magnet) {
  await chrome.tabs.create({ url: magnet, active: false });
}

async function torrentClientTest() {
  const { settings } = await getState();
  const permission = await ensureRequiredHostPermissions(settings);
  if (!permission.ok) return permission;
  const client = torrentClient(settings);
  if (client === "qbit") return qbitTest(settings);
  if (client === "transmission") return transmissionTest(settings);
  if (client === "deluge") return delugeTest(settings);
  if (client === "utorrent" || client === "bittorrent") return utorrentTest(settings);
  if (client === "aria2") return aria2Test(settings);
  throw new Error("This torrent client is not supported for direct WebUI sending.");
}

async function torrentClientAdd(magnet, settings) {
  const client = torrentClient(settings);
  if (client === "qbit") return qbitAdd(magnet, settings);
  if (client === "transmission") return transmissionAdd(magnet, settings);
  if (client === "deluge") return delugeAdd(magnet, settings);
  if (client === "utorrent" || client === "bittorrent") return utorrentAdd(magnet, settings);
  if (client === "aria2") return aria2Add(magnet, settings);
  throw new Error("This torrent client is not supported for direct WebUI sending.");
}

function torrentClient(settings) {
  return String(settings.torrentClient || (settings.delivery === "qbit" ? "qbit" : "qbit")).toLowerCase();
}

async function qbitTest(settings) {
  await qbitLogin(settings);
  const response = await fetch(`${trimSlash(settings.qbitHost)}/api/v2/app/version`, {
    credentials: "include"
  });
  if (!response.ok) throw new Error(`qBittorrent test failed: ${response.status}`);
  return { ok: true, version: await response.text() };
}

async function qbitAdd(magnet, settings) {
  await qbitLogin(settings);
  const form = new URLSearchParams();
  form.set("urls", magnet);
  if (settings.qbitCategory) form.set("category", settings.qbitCategory);
  const response = await fetch(`${trimSlash(settings.qbitHost)}/api/v2/torrents/add`, {
    method: "POST",
    credentials: "include",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: form
  });
  if (!response.ok) throw new Error(`qBittorrent add failed: ${response.status}`);
  const text = await response.text();
  if (text.trim().toLowerCase() === "fails.") throw new Error("qBittorrent rejected the magnet.");
}

async function qbitLogin(settings) {
  if (!settings.qbitHost || !settings.qbitUser) throw new Error("qBittorrent is not configured.");
  const form = new URLSearchParams();
  form.set("username", settings.qbitUser);
  form.set("password", settings.qbitPass || "");
  const response = await fetch(`${trimSlash(settings.qbitHost)}/api/v2/auth/login`, {
    method: "POST",
    credentials: "include",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: form
  });
  const text = await response.text();
  if (text.trim() !== "Ok.") throw new Error("qBittorrent login failed.");
}

async function transmissionTest(settings) {
  const data = await transmissionRpc(settings, "session-get", {});
  return { ok: true, version: data?.arguments?.version || "connected" };
}

async function transmissionAdd(magnet, settings) {
  await transmissionRpc(settings, "torrent-add", { filename: magnet });
}

async function transmissionRpc(settings, method, args) {
  const url = `${trimSlash(settings.qbitHost || "http://localhost:9091")}/transmission/rpc`;
  const headers = { "Content-Type": "application/json", ...basicAuthHeaders(settings) };
  let response = await fetch(url, {
    method: "POST",
    headers,
    body: JSON.stringify({ method, arguments: args }),
    credentials: "include"
  });
  if (response.status === 409) {
    const session = response.headers.get("X-Transmission-Session-Id");
    response = await fetch(url, {
      method: "POST",
      headers: { ...headers, "X-Transmission-Session-Id": session },
      body: JSON.stringify({ method, arguments: args }),
      credentials: "include"
    });
  }
  if (!response.ok) throw new Error(`Transmission failed: ${response.status}`);
  const data = await response.json();
  if (data.result !== "success") throw new Error(`Transmission rejected request: ${data.result || "unknown"}`);
  return data;
}

async function delugeTest(settings) {
  await delugeRpc(settings, "auth.login", [settings.qbitPass || ""]);
  const connected = await delugeRpc(settings, "web.connected", []);
  return { ok: true, version: connected?.result ? "connected" : "connected" };
}

async function delugeAdd(magnet, settings) {
  await delugeRpc(settings, "auth.login", [settings.qbitPass || ""]);
  const response = await delugeRpc(settings, "core.add_torrent_magnet", [magnet, {}]);
  if (response.error) throw new Error(response.error.message || "Deluge rejected the magnet.");
}

async function delugeRpc(settings, method, params) {
  const response = await fetch(`${trimSlash(settings.qbitHost || "http://localhost:8112")}/json`, {
    method: "POST",
    credentials: "include",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ id: Date.now(), method, params })
  });
  if (!response.ok) throw new Error(`Deluge failed: ${response.status}`);
  const data = await response.json();
  if (data.error) throw new Error(data.error.message || "Deluge request failed.");
  return data;
}

async function utorrentTest(settings) {
  const token = await utorrentToken(settings);
  return { ok: true, version: token ? "connected" : "connected" };
}

async function utorrentAdd(magnet, settings) {
  const token = await utorrentToken(settings);
  const url = `${trimSlash(settings.qbitHost || "http://localhost:8080")}/gui/?action=add-url&token=${encodeURIComponent(token)}&s=${encodeURIComponent(magnet)}`;
  const response = await fetch(url, {
    credentials: "include",
    headers: basicAuthHeaders(settings)
  });
  if (!response.ok) throw new Error(`uTorrent/BitTorrent failed: ${response.status}`);
}

async function utorrentToken(settings) {
  const response = await fetch(`${trimSlash(settings.qbitHost || "http://localhost:8080")}/gui/token.html`, {
    credentials: "include",
    headers: basicAuthHeaders(settings)
  });
  if (!response.ok) throw new Error(`uTorrent/BitTorrent token failed: ${response.status}`);
  const text = await response.text();
  const match = text.match(/>([^<]+)</);
  if (!match) throw new Error("Could not read uTorrent/BitTorrent token.");
  return match[1];
}

async function aria2Test(settings) {
  const data = await aria2Rpc(settings, "aria2.getVersion", []);
  return { ok: true, version: data?.result?.version || "connected" };
}

async function aria2Add(magnet, settings) {
  await aria2Rpc(settings, "aria2.addUri", [[magnet], {}]);
}

async function aria2Rpc(settings, method, params) {
  const rpcParams = settings.qbitPass ? [`token:${settings.qbitPass}`, ...params] : params;
  const response = await fetch(settings.qbitHost || "http://localhost:6800/jsonrpc", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ jsonrpc: "2.0", id: Date.now(), method, params: rpcParams })
  });
  if (!response.ok) throw new Error(`aria2 failed: ${response.status}`);
  const data = await response.json();
  if (data.error) throw new Error(data.error.message || "aria2 request failed.");
  return data;
}

function basicAuthHeaders(settings) {
  if (!settings.qbitUser) return {};
  return { Authorization: `Basic ${btoa(`${settings.qbitUser}:${settings.qbitPass || ""}`)}` };
}

async function getState() {
  const state = await chrome.storage.local.get(["settings", "shows", "meta"]);
  return {
    settings: { ...DEFAULTS.settings, ...(state.settings || {}) },
    shows: Array.isArray(state.shows) ? state.shows : [],
    meta: { ...DEFAULTS.meta, ...(state.meta || {}) }
  };
}

function normalizeTorrent(row) {
  const title = row.title || row.filename || "";
  const titleCode = parseCode(title);
  const season = Number(row.season ?? titleCode?.s ?? 0);
  const episode = Number(row.episode ?? titleCode?.e ?? 0);
  const hasSeason = Number.isFinite(season) && season > 0;
  const hasEpisode = Number.isFinite(episode) && episode >= 0;
  return {
    title,
    magnet: row.magnet_url || row.torrent_url || "",
    seeds: Number(row.seeds || 0),
    quality: extractQuality(title),
    uploader: extractUploader(title),
    season,
    episode,
    code: hasSeason && hasEpisode ? episodeCode(season, episode) : ""
  };
}

function titleMatchesShow(showName, torrentTitle) {
  const candidate = titleShowName(torrentTitle);
  if (!candidate) return false;
  return showTitlePartsMatch(showName, candidate);
}

function tvmazeTitleMatches(showName, candidate) {
  const candidateName = candidate?.name || "";
  if (!candidateName) return false;
  const wanted = splitShowTitle(showName);
  const found = splitShowTitle(candidateName);
  if (wanted.year || found.year) {
    const premieredYear = String(candidate?.premiered || "").slice(0, 4);
    found.year = found.year || premieredYear;
  }
  return showTitlePartsMatch(wanted, found);
}

function showTitlePartsMatch(wantedInput, foundInput) {
  const wanted = typeof wantedInput === "string" ? splitShowTitle(wantedInput) : wantedInput;
  const found = typeof foundInput === "string" ? splitShowTitle(foundInput) : foundInput;
  if (!wanted.baseKey || !found.baseKey) return false;
  if (wanted.baseKey !== found.baseKey) return false;
  if (wanted.year || found.year) return wanted.year === found.year;
  return true;
}

function titleShowName(title) {
  const match = String(title || "").match(/^(.*?)(?:[._\s-]+)?S\d{1,4}E\d{1,4}\b/i);
  if (!match) return "";
  return cleanImportedShowName(match[1]);
}

function extractQuality(title) {
  const match = String(title).match(/\b(2160p|1080p|720p|480p)\b/i);
  return match ? match[1] : "";
}

function extractUploader(title) {
  const match = String(title).match(/-([A-Za-z0-9]+)\s*(?:\[?eztv|\s+EZTV|$)/i);
  return match ? match[1] : "EZTV";
}

async function getUploaderRanks() {
  const state = await chrome.storage.local.get("uploaderRanks");
  return { ...DEFAULTS.uploaderRanks, ...(state.uploaderRanks || {}) };
}

function rank(item, show, settings, uploaderRanks) {
  const uploaderRank = uploaderRankFor(item.uploader, settings, uploaderRanks);
  const qualityRank = indexOrMax(preferredQualitiesForShow(show, settings), item.quality);
  return uploaderRank * 10000 + qualityRank * 100 - Number(item.seeds || 0) / 1000;
}

function preferredQualitiesForShow(show, settings) {
  const base = listFromText(settings.preferredQualities);
  const preferred = normalizeQuality(show?.preferredQuality || "");
  if (!preferred) return base;
  return [preferred, ...base.filter((quality) => normalizeQuality(quality) !== preferred)];
}

function uploaderRankFor(uploader, settings, uploaderRanks) {
  const preferredRank = indexOrMax(settings.preferredUploaders, uploader);
  if (preferredRank !== 999) return preferredRank;
  const normalized = normalizeUploader(uploader);
  if (!normalized) return 999;
  if (Object.prototype.hasOwnProperty.call(uploaderRanks, normalized)) return Number(uploaderRanks[normalized]) || 99;
  uploaderRanks[normalized] = 99;
  chrome.storage.local.set({ uploaderRanks });
  return 99;
}

function indexOrMax(list, value) {
  const normalized = list.map((item) => normalize(item));
  const index = normalized.indexOf(normalize(value));
  return index === -1 ? 999 : index;
}

function parseCode(value) {
  const match = parseEpisodeReference(value);
  return match ? { code: episodeCode(match.season, match.episode), s: match.season, e: match.episode } : null;
}

function parseShowInput(value) {
  let text = String(value || "").trim();
  let lastSeen = "";
  let targetSeason = null;
  const preferredQuality = extractQuality(text);

  const exportMatch = text.match(/^(.*?)\s*\|\s*((?:S\d{1,4}E\d{1,4})|(?:\d{1,4}x\d{1,4}))\s*$/i);
  if (exportMatch) {
    const parsedEpisode = parseEpisodeReference(exportMatch[2]);
    const seasonTarget = extractSeasonTarget(exportMatch[1]);
    return {
      name: cleanImportedShowName(stripReleaseWords(seasonTarget.name)),
      lastSeen: parsedEpisode ? episodeCode(parsedEpisode.season, parsedEpisode.episode) : "",
      targetSeason: seasonTarget.targetSeason || (parsedEpisode?.episode === 0 ? parsedEpisode.season : null),
      preferredQuality: extractQuality(exportMatch[1])
    };
  }

  const episode = parseEpisodeReference(text);
  if (episode) {
    lastSeen = episodeCode(episode.season, episode.episode);
    targetSeason = episode.season;
    text = text.replace(episode.raw, " ");
  } else {
    const seasonWord = text.match(/\b(?:season\s*|s)(\d{1,3})\b/i);
    if (seasonWord) {
      targetSeason = Number(seasonWord[1]);
      text = text.replace(seasonWord[0], " ");
    }
  }

  text = stripReleaseWords(text);
  return { name: cleanImportedShowName(text), lastSeen, targetSeason, preferredQuality };
}

function stripReleaseWords(value) {
  let text = String(value || "")
    .replace(/\[[^\]]*\]/g, " ")
    .replace(/\.(?:mkv|mp4|avi)\b/ig, " ");
  for (let i = 0; i < 4; i += 1) {
    text = text.replace(/[.\s_-]+\b(?:x264|x265|h264|h265|hevc|avc|webrip|web-dl|web|hdtv|bluray|proper|repack)\b(?:[.\s_-]+[A-Za-z0-9]+)?\s*$/i, " ");
  }
  return text.replace(/\b(2160p|1080p|720p|480p|webrip|web-dl|web|hdtv|bluray|x264|x265|h264|h265|hevc|avc|proper|repack)\b/ig, " ");
}

function seasonBaseline(season) {
  return season ? `S${String(season).padStart(2, "0")}E00` : "";
}

function extractSeasonTarget(value) {
  const text = String(value || "");
  const match = text.match(/\b(?:season\s*|s)(\d{1,3})\b/i);
  if (!match) return { name: text, targetSeason: null };
  return {
    name: text.replace(match[0], " "),
    targetSeason: Number(match[1])
  };
}

function normalizeEpisode(value) {
  const parsed = parseCode(value);
  return parsed ? parsed.code : "";
}

function parseEpisodeReference(value) {
  const text = String(value || "");
  let match = text.match(/\bseason\s*(\d{1,4})\s*(?:episode|ep|e)\s*(\d{1,4})\b/i);
  if (match) return { raw: match[0], season: Number(match[1]), episode: Number(match[2]) };
  match = text.match(/\bS(\d{1,4})E(\d{1,4})\b/i);
  if (match) return { raw: match[0], season: Number(match[1]), episode: Number(match[2]) };
  match = text.match(/\b(\d{1,4})x(\d{1,4})\b/i);
  if (match) return { raw: match[0], season: Number(match[1]), episode: Number(match[2]) };
  return null;
}

function episodeCode(season, episode) {
  return `S${String(Number(season || 0)).padStart(2, "0")}E${String(Number(episode || 0)).padStart(2, "0")}`;
}

function latestPerShow(items) {
  if (!items.length) return items;
  const latest = items.reduce((best, item) => {
    if (!best) return item;
    return compareCodes(item.code, best.code) > 0 ? item : best;
  }, null);
  return latest ? [latest] : [];
}

function pruneResultsAfter(results, lastSeen) {
  const last = parseCode(lastSeen);
  if (!last) return results || [];
  return (results || []).filter((item) => compareCodes(item.code, last.code) > 0);
}

function cleanImportedShowName(value) {
  let cleaned = String(value || "")
    .replace(/\[[^\]]*\]/g, " ")
    .replace(/\.(?:mkv|mp4|avi)$/i, "")
    .replace(/['"’]/g, "")
    .replace(/[_-]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  cleaned = cleaned.replace(/[.\s]+$/g, "").trim();
  if (/^(?:[A-Za-z]\.)+[A-Za-z]$/.test(cleaned)) return cleaned;
  return cleaned.replace(/[.:]+/g, " ").replace(/\s+/g, " ").trim();
}

function splitShowTitle(value) {
  const yearMatch = String(value || "").match(/(?<!\d)(19|20)\d{2}(?!\d)/);
  const year = yearMatch ? yearMatch[0] : "";
  const withoutYear = String(value || "").replace(/(?<!\d)(19|20)\d{2}(?!\d)/g, " ");
  return {
    year,
    base: cleanImportedShowName(withoutYear),
    baseKey: compactBaseShowNameKey(withoutYear)
  };
}

function compareCodes(a, b) {
  const left = typeof a === "string" ? parseCode(a) : a;
  const right = typeof b === "string" ? parseCode(b) : b;
  if (!left || !right) return 0;
  if (left.s !== right.s) return left.s - right.s;
  return left.e - right.e;
}

function dedupeBy(items, keyFn) {
  const seen = new Set();
  return items.filter((item) => {
    const key = keyFn(item);
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function sortShows(shows) {
  shows.sort((a, b) => {
    const nameCompare = normalizeShowName(a.name).localeCompare(normalizeShowName(b.name));
    if (nameCompare) return nameCompare;
    return Number(a.targetSeason || 0) - Number(b.targetSeason || 0);
  });
}

function listFromText(value) {
  if (Array.isArray(value)) return value.map(String).map((item) => item.trim()).filter(Boolean);
  return String(value || "").split(",").map((item) => item.trim()).filter(Boolean);
}

function rssSourcesFromValue(value) {
  if (!value) return [];
  const rows = Array.isArray(value)
    ? value
    : String(value).split(/\r?\n/).map((line) => {
      const parts = line.split(/\s*\|\s*/);
      const url = parts.length > 1 ? parts.pop() : line;
      return { name: parts.join(" | ").trim(), url: String(url || "").trim() };
    });
  return rows.map((row) => {
    if (typeof row === "string") return { name: "", url: row.trim() };
    return { name: String(row.name || "").trim(), url: String(row.url || "").trim() };
  }).filter((row) => /^https?:\/\//i.test(row.url));
}

function cleanImdb(value) {
  return String(value || "").replace(/^tt/i, "").replace(/\D/g, "");
}

function normalize(value) {
  return String(value || "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
}

function normalizeUploader(value) {
  return String(value || "").toLowerCase().replace(/\s+/g, "");
}

function normalizeQuality(value) {
  const match = String(value || "").match(/\b(2160p|1080p|720p|480p)\b/i);
  return match ? match[1].toLowerCase() : "";
}

function normalizeShowName(value) {
  return String(value || "")
    .toLowerCase()
    .replace(/&/g, " and ")
    .replace(/['"’]/g, "")
    .replace(/[._:-]+/g, " ")
    .replace(/\b(?:us|uk|au)\b/g, " ")
    .replace(/\b(?:19|20)\d{2}\b/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function compactShowNameKey(value) {
  return normalizeShowName(value).replace(/[^a-z0-9]+/g, "");
}

function compactBaseShowNameKey(value) {
  return normalizeShowName(String(value || "").replace(/(?<!\d)(19|20)\d{2}(?!\d)/g, " ")).replace(/[^a-z0-9]+/g, "");
}

function todayIsoDate() {
  return new Date().toISOString().slice(0, 10);
}

function addDaysIso(dateValue, days) {
  const date = new Date(`${dateValue}T00:00:00Z`);
  date.setUTCDate(date.getUTCDate() + days);
  return date.toISOString().slice(0, 10);
}

function trimSlash(value) {
  return String(value || "").replace(/\/+$/, "");
}
