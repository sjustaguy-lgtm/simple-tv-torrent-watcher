Simple TV Torrent Watcher 2.0.7.4 fixes a missed-episode case where new releases could be hidden when EZTV reports them with zero seeders.

- Keeps exact new episode matches visible even when they are below the Min Seeders setting.
- Still uses Min Seeders as a ranking preference when alternatives are available.
- Adds stricter title checking on EZTV API rows so one show cannot borrow releases from a similarly named show.
- Keeps the live scan list visible after an up-to-date scan and shows the saved last episode marker.
- Existing watchlists and settings remain in browser storage.
