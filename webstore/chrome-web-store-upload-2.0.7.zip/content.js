(() => {
  const app = {
    context: readShowContext(),
    root: null,
    panel: null,
    body: null,
    status: null
  };

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "get-show-context") sendResponse(app.context);
  });

  injectStyles();
  buildUi();

  function readShowContext() {
    const context = { name: "", imdbId: "" };
    const heading = Array.from(document.querySelectorAll("h1, h2")).find((node) =>
      /torrent download|watch & download/i.test(node.textContent || "")
    );
    const fromHeading = heading ? heading.textContent.replace(/\s*Torrent Download.*$/i, "").trim() : "";
    const fromTitle = document.title.replace(/\s*Torrent Download.*$/i, "").replace(/\s*\|\s*EZTV.*$/i, "").trim();
    const urlMatch = location.pathname.match(/\/shows\/\d+\/([^/]+)/i);
    const fromUrl = urlMatch ? urlMatch[1].replace(/-/g, " ").trim() : "";
    context.name = [fromUrl, fromHeading, fromTitle].find((value) => value && !isGenericShowName(value)) || "";

    const imdbLink = document.querySelector('a[href*="imdb.com/title/tt"]');
    if (imdbLink) {
      const match = imdbLink.href.match(/tt\d+/i);
      if (match) context.imdbId = match[0].replace(/^tt/i, "");
    }
    return context;
  }

  function buildUi() {
    if (document.getElementById("stw-root")) return;
    const root = document.createElement("div");
    root.id = "stw-root";
    root.innerHTML = `
      <div class="stw-bar">
        <button type="button" data-action="scan">Scan for New Episodes</button>
        <button type="button" data-action="season-dates">Check Season Dates</button>
        <button type="button" data-action="watchlist">Watchlist</button>
        <button type="button" data-action="add">Add Show to Watchlist</button>
        <button type="button" data-action="settings">Settings</button>
        <span class="stw-pill" data-role="count">loading</span>
      </div>
      <div class="stw-panel" hidden>
        <div class="stw-head">
          <strong data-role="title">TV Watcher</strong>
          <button type="button" data-action="close">x</button>
        </div>
        <div class="stw-status" data-role="status"></div>
        <div class="stw-body" data-role="body"></div>
      </div>
    `;

    const anchor =
      document.querySelector('form[action*="search"]')?.parentElement ||
      document.querySelector("body > table") ||
      document.body;
    anchor.prepend(root);

    app.root = root;
    app.panel = root.querySelector(".stw-panel");
    app.body = root.querySelector('[data-role="body"]');
    app.status = root.querySelector('[data-role="status"]');
    root.addEventListener("click", handleClick);
    root.addEventListener("change", handleChange);
    refreshCount();
  }

  async function handleClick(event) {
    const button = event.target.closest("button");
    if (!button || !app.root.contains(button)) return;
    const { action } = button.dataset;

    if (action === "close") closePanel();
    if (action === "add") await renderAddShow();
    if (action === "scan") await scanAll();
    if (action === "season-dates") await checkSeasonDates();
    if (action === "watchlist") await renderWatchlist();
    if (action === "settings") await openExtensionSettings();
    if (action === "save-show") await saveShowFromForm();
    if (action === "import-shows") await importShows();
    if (action === "copy-export") await copyExport();
    if (action === "fill-import") await fillImportFromExport();
    if (action === "scan-show") await scanOne(button.dataset.id);
    if (action === "remove-show") await removeShow(button.dataset.id);
    if (action === "send-one") await sendOne(button);
    if (action === "mark-seen") await markSeen(button.dataset.id, button.dataset.code);
    if (action === "send-selected") await sendSelected();
    if (action === "mark-selected-seen") await markSelectedSeen();
    if (action === "select-all-results") setAllResults(true);
    if (action === "select-no-results") setAllResults(false);
  }

  function handleChange(event) {
    if (event.target.matches('[data-role="show-enabled"]')) {
      saveEnabledState();
    }
  }

  async function renderAddShow() {
    openPanel("Add Show to Watchlist");
    const name = isGenericShowName(app.context.name) ? "" : (app.context.name || "");
    const imdb = app.context.imdbId ? `tt${app.context.imdbId}` : "";
    app.body.innerHTML = `
      <div class="stw-card stw-form">
        <label>Show name, qBit filename, export line, or season request
          <input id="stw-show-name" value="${escapeAttr(name)}" placeholder="Your Friends and Neighbors S02E07 1080p HEVC x265-MeGusta [eztv]">
        </label>
        <label>IMDB id
          <input id="stw-imdb" value="${escapeAttr(imdb)}" placeholder="Optional, example: tt15017118">
        </label>
        <label>Last episode already handled
          <input id="stw-last-seen" placeholder="Optional, example: S03E04">
        </label>
        <div class="stw-actions stw-left">
          <button type="button" data-action="save-show">Add to Watchlist</button>
        </div>
      </div>
      <div class="stw-card stw-form">
        <label>Mass import
          <textarea id="stw-bulk-import" rows="9" placeholder="M.I.A | S01E09&#10;Boston.Blue.S01E19.1080p.HEVC.x265-MeGusta[eztvx.to]&#10;The Boys season 4"></textarea>
        </label>
        <label>Export watchlist
          <textarea id="stw-export" rows="9" readonly></textarea>
        </label>
        <div class="stw-actions stw-left">
          <button type="button" data-action="import-shows">Import Pasted Names</button>
          <button type="button" data-action="copy-export">Copy Export</button>
          <button type="button" data-action="fill-import">Put Export In Import Box</button>
        </div>
      </div>
    `;
    await fillExportBox();
    setStatus(name ? `Current page detected: ${name}` : "Type a show name to add it manually.");
  }

  async function saveShowFromForm() {
    const show = {
      name: valueOf("stw-show-name"),
      imdbId: valueOf("stw-imdb"),
      lastSeen: valueOf("stw-last-seen")
    };
    setStatus("Adding show...");
    const response = await send({ type: "add-show", show });
    if (!response.ok) {
      setStatus(response.error);
      return;
    }
    await refreshCount();
    setStatus(`${response.updated ? "Updated" : "Added"} ${displayShowLabel(response.show)}.`);
    await renderWatchlist(false);
  }

  async function scanAll() {
    openPanel("Scan for New Episodes");
    const { shows } = await getState();
    const enabled = shows.filter((show) => show.enabled !== false);
    if (!enabled.length) {
      app.body.innerHTML = `<div class="stw-empty">No enabled shows in the watchlist.</div>`;
      setStatus("Nothing to scan.");
      return;
    }
    const seasonCheck = await send({ type: "maybe-check-season-dates" });
    app.body.innerHTML = `
      <div class="stw-card stw-scan-card">
        <div class="stw-muted">Live scan</div>
        <div id="stw-live-scan" class="stw-live-scan"></div>
      </div>
      <div id="stw-scan-existing"></div>
    `;
    const live = document.getElementById("stw-live-scan");
    const existing = document.getElementById("stw-scan-existing");
    existing.innerHTML = await renderCurrentResultsHtml();
    let checked = 0;
    let found = 0;
    const errors = [];
    if (seasonCheck?.ran) {
      live.insertAdjacentHTML("afterbegin", `<div>Checked upcoming season dates: ${Number(seasonCheck.updated || 0)} date(s) updated.</div>`);
    }
    for (const show of enabled) {
      checked += 1;
      live.insertAdjacentHTML("afterbegin", `<div>Scanning ${escapeHtml(displayShowLabel(show))}...</div>`);
      setStatus(`[${checked}/${enabled.length}] Scanning ${displayShowLabel(show)}...`);
      const response = await send({ type: "scan-show", id: show.id });
      if (!response.ok) {
        errors.push(`${show.name}: ${response.error}`);
        live.insertAdjacentHTML("afterbegin", `<div class="stw-muted">Error: ${escapeHtml(show.name)} - ${escapeHtml(response.error)}</div>`);
        continue;
      }
      const count = response.results.length;
      found += count;
      const scanText = response.skipped
        ? (response.seriesStatus
          ? `not scanning (${response.seriesStatus})`
          : `paused until ${response.skipUntil}`)
        : (count ? `${count} new` : "up to date");
      live.insertAdjacentHTML("afterbegin", `<div>${escapeHtml(displayShowLabel(response.show))}: ${escapeHtml(scanText)}</div>`);
    }
    if (!found) {
      setStatus(`Checked ${checked} show(s). No new episodes found.${errors.length ? ` Errors: ${errors.join(" | ")}` : ""}`);
      const hasRows = await hasResultRows();
      if (hasRows) await renderResults(false);
      else app.body.innerHTML = `<div class="stw-empty">Up to date on all shows.</div>`;
      return;
    }
    setStatus(`Checked ${checked} show(s). Found ${found} new episode result(s).${errors.length ? ` Errors: ${errors.join(" | ")}` : ""}`);
    await renderResults(false);
  }

  async function checkSeasonDates() {
    openPanel("Check Season Dates");
    app.body.innerHTML = `<div class="stw-card">Checking upcoming season release dates...</div>`;
    setStatus("Checking TVMaze for upcoming episodes...");
    const response = await send({ type: "check-season-dates" });
    if (!response.ok) {
      setStatus(response.error || "Could not check season dates.");
      return;
    }
    const lines = response.skippedUntil?.length
      ? response.skippedUntil.map((line) => `<div>${escapeHtml(line)}</div>`).join("")
      : '<div class="stw-empty">No future season dates found yet.</div>';
    const ended = response.endedShows?.length
      ? `<div class="stw-card"><strong>Ended / canceled</strong>${response.endedShows.map((show) => `
          <div class="stw-show-row">
            <span>${escapeHtml(show.name)}: ${escapeHtml(show.status)}</span>
            <button type="button" data-action="remove-show" data-id="${escapeAttr(show.id)}">Remove Ended Show</button>
          </div>
        `).join("")}<div class="stw-muted">These shows are no longer included in routine scans.</div></div>`
      : "";
    app.body.innerHTML = `<div class="stw-card"><strong>Paused until a return date</strong>${lines}</div>${ended}`;
    setStatus(`Checked ${response.checked || 0} show(s). Updated ${response.updated || 0}. Cleared ${response.cleared || 0}.${response.errors?.length ? ` Errors: ${response.errors.join(" | ")}` : ""}`);
    await refreshCount();
  }

  async function renderResults(open = true, showFilterId = "") {
    if (open) openPanel("Review / Send Results");
    app.body.innerHTML = await renderCurrentResultsHtml(showFilterId);
  }

  async function renderCurrentResultsHtml(showFilterId = "") {
    const rows = await getResultRows(showFilterId);
    if (!rows.length) return `<div class="stw-empty">Up to date on all shows.</div>`;
    return `
      <div class="stw-toolbar">
        <button type="button" data-action="send-selected">Send Selected</button>
        <button type="button" data-action="mark-selected-seen">I Already Have Selected</button>
        <button type="button" data-action="select-all-results">Select All</button>
        <button type="button" data-action="select-no-results">Select None</button>
      </div>
      <div class="stw-result-list">
        ${rows.map(({ show, item }) => renderResult(show, item)).join("")}
      </div>
    `;
  }

  async function hasResultRows(showFilterId = "") {
    return (await getResultRows(showFilterId)).length > 0;
  }

  async function getResultRows(showFilterId = "") {
    const { shows } = await getState();
    const rows = [];
    for (const show of [...shows].sort(compareShows)) {
      if (showFilterId && show.id !== showFilterId) continue;
      for (const item of show.results || []) {
        if (show.lastSeen && compareCodes(item.code, show.lastSeen) <= 0) continue;
        rows.push({ show, item });
      }
    }
    return rows;
  }

  function renderResult(show, item) {
    return `
      <div class="stw-result">
        <label class="stw-check">
          <input type="checkbox" data-result="1" data-show="${escapeAttr(show.id)}" data-code="${escapeAttr(item.code)}" data-magnet="${escapeAttr(item.magnet)}" data-title="${escapeAttr(item.title)}" checked>
          <span>
            <strong>${escapeHtml(show.name)} ${escapeHtml(item.code)}</strong>
            <span class="stw-muted">${escapeHtml(item.quality || "?")} / ${escapeHtml(item.uploader || "?")} / ${Number(item.seeds || 0)} seeds</span>
            <span class="stw-title">${escapeHtml(item.title || "")}</span>
          </span>
        </label>
        <div class="stw-actions">
          <button type="button" data-action="send-one" data-id="${escapeAttr(show.id)}" data-code="${escapeAttr(item.code)}" data-magnet="${escapeAttr(item.magnet)}" data-title="${escapeAttr(item.title)}">Send</button>
          <button type="button" data-action="mark-seen" data-id="${escapeAttr(show.id)}" data-code="${escapeAttr(item.code)}">I already have this episode</button>
        </div>
      </div>
    `;
  }

  async function sendSelected() {
    const items = Array.from(app.root.querySelectorAll('[data-result="1"]:checked')).map((node) => ({
      showId: node.dataset.show,
      code: node.dataset.code,
      magnet: node.dataset.magnet,
      title: node.dataset.title
    }));
    if (!items.length) {
      setStatus("No results selected.");
      return;
    }
    setStatus(`Sending ${items.length} selected item(s)...`);
    const response = await send({ type: "send-magnets", items });
    const errors = response.errors?.length ? ` Errors: ${response.errors.join(" | ")}` : "";
    setStatus(`Sent ${response.sent || 0} item(s).${errors}`);
    await renderResults(false);
  }

  async function sendOne(button) {
    setStatus(`Sending ${button.dataset.code}...`);
    const response = await send({ type: "send-magnets", items: [{
      showId: button.dataset.id,
      code: button.dataset.code,
      magnet: button.dataset.magnet,
      title: button.dataset.title || button.dataset.code
    }] });
    const errors = response.errors?.length ? ` ${response.errors.join(" | ")}` : "";
    setStatus(`Sent ${response.sent || 0}.${errors}`);
    await renderResults(false);
  }

  async function markSelectedSeen() {
    const items = Array.from(app.root.querySelectorAll('[data-result="1"]:checked')).map((node) => ({
      showId: node.dataset.show,
      code: node.dataset.code
    }));
    if (!items.length) {
      setStatus("No results selected.");
      return;
    }
    let updated = 0;
    const errors = [];
    for (const item of items) {
      const response = await send({ type: "mark-seen", id: item.showId, code: item.code });
      if (response.ok) updated += 1;
      else errors.push(response.error || `${item.code} failed`);
    }
    setStatus(`Marked ${updated} already-have episode(s).${errors.length ? ` Errors: ${errors.join(" | ")}` : ""}`);
    await renderResults(false);
  }

  async function renderWatchlist(open = true) {
    if (open) openPanel("Watchlist");
    const { shows } = await getState();
    await refreshCount(shows);
    if (!shows.length) {
      app.body.innerHTML = `<div class="stw-empty">No shows yet. Click Add Show to Watchlist.</div>`;
      return;
    }
    const sorted = [...shows].sort(compareShows);
    const searching = sorted.filter((show) => !isPausedShow(show) && !isEndedShow(show));
    const paused = sorted.filter((show) => isPausedShow(show) || isEndedShow(show));
    app.body.innerHTML = `
      <div class="stw-section-title">Searching Now (${searching.length})</div>
      ${searching.length ? searching.map(renderWatchlistShow).join("") : '<div class="stw-empty">No shows are currently searching.</div>'}
      <div class="stw-section-title">Paused / Ended (${paused.length})</div>
      ${paused.length ? paused.map(renderWatchlistShow).join("") : '<div class="stw-empty">No shows are paused.</div>'}
    `;
  }

  function renderWatchlistShow(show) {
    const ended = isEndedShow(show);
    const stateText = ended
      ? ` · Status: ${escapeHtml(show.seriesStatus)}`
      : (show.skipUntil ? ` · Paused until ${escapeHtml(show.skipUntil)}` : "");
    return `
      <div class="stw-card">
        <div class="stw-show-row">
          <label class="stw-check">
            <input type="checkbox" data-role="show-enabled" data-id="${escapeAttr(show.id)}" ${show.enabled !== false ? "checked" : ""}>
            <span>
              <strong>${escapeHtml(show.name)}</strong>
              <span class="stw-muted">Last: ${escapeHtml(show.lastSeen || "not set")} ${show.targetSeason ? `· Season ${show.targetSeason}` : ""}${show.preferredQuality ? ` · Quality ${escapeHtml(show.preferredQuality)}` : ""} · ${escapeHtml(show.imdbId ? `tt${show.imdbId}` : "auto")}${stateText} · Results: ${(show.results || []).length}</span>
            </span>
          </label>
          <div class="stw-actions">
            ${ended ? "" : `<button type="button" data-action="scan-show" data-id="${escapeAttr(show.id)}">Scan for New Episodes</button>`}
            <button type="button" data-action="remove-show" data-id="${escapeAttr(show.id)}">${ended ? "Remove Ended Show" : "Remove"}</button>
          </div>
        </div>
      </div>
    `;
  }

  async function saveEnabledState() {
    const { shows } = await getState();
    for (const show of shows) {
      const checkbox = app.root.querySelector(`[data-role="show-enabled"][data-id="${cssEscape(show.id)}"]`);
      if (checkbox) await send({ type: "set-show-enabled", id: show.id, enabled: checkbox.checked });
    }
    await refreshCount();
  }

  async function scanOne(id) {
    openPanel("Scan for New Episodes");
    app.body.innerHTML = `<div class="stw-card">Scanning selected show...</div>`;
    setStatus("Scanning show...");
    const response = await send({ type: "scan-show", id });
    if (!response.ok) {
      setStatus(response.error);
      return;
    }
    if (!response.results.length) {
      const message = response.seriesStatus
        ? `${displayShowLabel(response.show)} is marked ${response.seriesStatus} and is no longer scanned.`
        : (response.skipped
          ? `${displayShowLabel(response.show)} is paused until ${response.skipUntil}.`
          : `${displayShowLabel(response.show)} is up to date.`);
      app.body.innerHTML = `<div class="stw-empty">${escapeHtml(message)}</div>`;
      setStatus(response.seriesStatus ? "Show is ended / canceled." : (response.skipped ? "Show is paused." : "No new episodes found."));
      return;
    }
    setStatus(`Found ${response.results.length} new result(s).`);
    await renderResults(false, id);
  }

  async function removeShow(id) {
    const response = await send({ type: "remove-show", id });
    setStatus(response.ok ? "Removed show." : response.error);
    await renderWatchlist(false);
  }

  async function markSeen(id, code) {
    const response = await send({ type: "mark-seen", id, code });
    setStatus(response.ok ? `Marked ${code} as seen.` : response.error);
    await renderResults(false);
  }

  async function openExtensionSettings() {
    setStatus("Opening extension Settings...");
    const response = await send({ type: "open-settings" });
    if (response.ok) {
      setStatus("Opened Settings in a new extension tab.");
    } else {
      setStatus(response.error || "Click the extension icon, then open Settings.");
    }
  }

  async function fillExportBox() {
    const { shows } = await getState();
    const exportText = [...shows].sort(compareShows).map((show) => {
      const target = show.targetSeason ? ` season ${show.targetSeason}` : "";
      const suffix = show.lastSeen ? `${target} | ${show.lastSeen}` : target;
      const quality = show.preferredQuality ? ` ${show.preferredQuality}` : "";
      return `${show.name || ""}${quality}${suffix}`.trim();
    }).filter(Boolean).join("\n");
    const box = document.getElementById("stw-export");
    if (box) box.value = exportText;
  }

  async function importShows() {
    const raw = valueOf("stw-bulk-import");
    const lines = raw.split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
    if (!lines.length) {
      setStatus("Paste at least one show or torrent name first.");
      return;
    }
    let added = 0;
    let updated = 0;
    for (const line of lines) {
      const parsed = parseBulkLine(line);
      if (!parsed.name) continue;
      const before = (await getState()).shows;
      const existed = before.some((show) => sameImportedShow(show, parsed));
      const response = await send({
        type: "add-show",
        show: {
          name: parsed.name,
          imdbId: "",
          lastSeen: parsed.lastSeen,
          targetSeason: parsed.targetSeason || null,
          preferredQuality: parsed.preferredQuality || ""
        }
      });
      if (response.ok && existed && parsed.lastSeen) {
        const show = (await getState()).shows.find((item) => sameImportedShow(item, parsed));
        if (show) await send({ type: "mark-seen", id: show.id, code: parsed.lastSeen });
      }
      if (response.ok) {
        if (response.updated || existed) updated += 1;
        else added += 1;
      }
    }
    await refreshCount();
    await fillExportBox();
    setStatus(`Imported ${added} new show(s), updated ${updated}. Export format like M.I.A | S01E09 can be pasted back in.`);
  }

  async function copyExport() {
    const text = valueOf("stw-export");
    if (!text) {
      setStatus("Nothing to export yet.");
      return;
    }
    try {
      await navigator.clipboard.writeText(text);
      setStatus("Export copied.");
    } catch {
      const box = document.getElementById("stw-export");
      box.focus();
      box.select();
      document.execCommand("copy");
      setStatus("Export selected and copied.");
    }
  }

  function fillImportFromExport() {
    const text = valueOf("stw-export");
    const box = document.getElementById("stw-bulk-import");
    if (box) box.value = text;
    setStatus("Put export lines into the import box.");
  }

  function displayShowLabel(show) {
    return `${show.name}${show.targetSeason ? ` season ${show.targetSeason}` : ""}`;
  }

  function compareShows(a, b) {
    const nameCompare = normalizeShowName(a.name).localeCompare(normalizeShowName(b.name));
    if (nameCompare) return nameCompare;
    return Number(a.targetSeason || 0) - Number(b.targetSeason || 0);
  }

  function isPausedShow(show) {
    return Boolean(show.skipUntil && show.skipUntil > new Date().toISOString().slice(0, 10));
  }

  function isEndedShow(show) {
    return /ended|cancelled|canceled/i.test(String(show.seriesStatus || ""));
  }

  function setAllResults(checked) {
    app.root.querySelectorAll('[data-result="1"]').forEach((node) => {
      node.checked = checked;
    });
  }

  async function getState() {
    const response = await send({ type: "get-state" });
    return {
      settings: response.settings || {},
      shows: response.shows || []
    };
  }

  async function refreshCount(existingShows = null) {
    const shows = existingShows || (await getState()).shows;
    const count = shows.filter((show) => show.enabled !== false).length;
    const pill = app.root?.querySelector('[data-role="count"]');
    if (pill) pill.textContent = `${count}/${shows.length} watched`;
  }

  function openPanel(title) {
    app.panel.hidden = false;
    app.root.querySelector('[data-role="title"]').textContent = title || "TV Watcher";
  }

  function closePanel() {
    app.panel.hidden = true;
  }

  function setStatus(text) {
    app.panel.hidden = false;
    app.status.textContent = text || "";
  }

  function send(message) {
    return chrome.runtime.sendMessage(message);
  }

  function valueOf(id) {
    return (document.getElementById(id)?.value || "").trim();
  }

  function parseBulkLine(line) {
    const preferredQuality = extractQuality(line);
    const exportMatch = String(line || "").match(/^(.*?)\s*\|\s*((?:S\d{1,4}E\d{1,4})|(?:\d{1,4}x\d{1,4}))\s*$/i);
    if (exportMatch) {
      const episode = parseEpisodeReference(exportMatch[2]);
      const seasonTarget = extractSeasonTarget(exportMatch[1]);
      return {
        name: cleanImportedShowName(stripReleaseWords(seasonTarget.name)),
        lastSeen: episode ? episodeCode(episode.season, episode.episode) : "",
        targetSeason: seasonTarget.targetSeason || (episode?.episode === 0 ? episode.season : null),
        preferredQuality: extractQuality(exportMatch[1])
      };
    }
    const episode = parseEpisodeReference(line);
    let name = String(line || "");
    let lastSeen = "";
    let targetSeason = null;
    if (episode) {
      lastSeen = episodeCode(episode.season, episode.episode);
      targetSeason = episode.season;
      name = name.replace(episode.raw, " ");
    } else {
      const seasonWord = name.match(/\b(?:season\s*|s)(\d{1,3})\b/i);
      if (seasonWord) {
        targetSeason = Number(seasonWord[1]);
        name = name.replace(seasonWord[0], " ");
      }
    }
    name = stripReleaseWords(name);
    return { name: cleanImportedShowName(name), lastSeen, targetSeason, preferredQuality };
  }

  function extractQuality(value) {
    const match = String(value || "").match(/\b(2160p|1080p|720p|480p)\b/i);
    return match ? match[1].toLowerCase() : "";
  }

  function stripReleaseWords(value) {
    let text = String(value || "")
      .replace(/\[[^\]]*\]/g, " ")
      .replace(/\.(?:mkv|mp4|avi)\b/ig, " ");
    for (let i = 0; i < 4; i += 1) {
      text = text.replace(/[.\s_-]+\b(?:x264|x265|h264|h265|hevc|avc|webrip|web-dl|web|hdtv|bluray|proper|repack)\b(?:[.\s_-]+[A-Za-z0-9]+)?\s*$/i, " ");
    }
    return text.replace(/\b(2160p|1080p|720p|480p|webrip|web-dl|web|hdtv|bluray|x264|x265|h264|h265|hevc|avc|proper|repack)\b/ig, " ");
  }

  function extractSeasonTarget(value) {
    const text = String(value || "");
    const match = text.match(/\b(?:season\s*|s)(\d{1,3})\b/i);
    if (!match) return { name: text, targetSeason: null };
    return {
      name: text.replace(match[0], " "),
      targetSeason: Number(match[1])
    };
  }

  function normalizeEpisode(value) {
    const match = parseEpisodeReference(value);
    return match ? episodeCode(match.season, match.episode) : "";
  }

  function parseEpisodeReference(value) {
    const text = String(value || "");
    let match = text.match(/\bseason\s*(\d{1,4})\s*(?:episode|ep|e)\s*(\d{1,4})\b/i);
    if (match) return { raw: match[0], season: Number(match[1]), episode: Number(match[2]) };
    match = text.match(/\bS(\d{1,4})E(\d{1,4})\b/i);
    if (match) return { raw: match[0], season: Number(match[1]), episode: Number(match[2]) };
    match = text.match(/\b(\d{1,4})x(\d{1,4})\b/i);
    if (match) return { raw: match[0], season: Number(match[1]), episode: Number(match[2]) };
    return null;
  }

  function episodeCode(season, episode) {
    return `S${String(Number(season || 0)).padStart(2, "0")}E${String(Number(episode || 0)).padStart(2, "0")}`;
  }

  function parseCode(value) {
    const match = String(value || "").match(/S(\d{1,4})E(\d{1,4})/i);
    return match ? { code: `S${match[1].padStart(2, "0")}E${match[2].padStart(2, "0")}`, s: Number(match[1]), e: Number(match[2]) } : null;
  }

  function compareCodes(a, b) {
    const left = typeof a === "string" ? parseCode(a) : a;
    const right = typeof b === "string" ? parseCode(b) : b;
    if (!left || !right) return 0;
    if (left.s !== right.s) return left.s - right.s;
    return left.e - right.e;
  }

  function cleanImportedShowName(value) {
    let cleaned = String(value || "")
      .replace(/\[[^\]]*\]/g, " ")
      .replace(/\.(?:mkv|mp4|avi)$/i, "")
      .replace(/['"’]/g, "")
      .replace(/[_-]+/g, " ")
      .replace(/\s+/g, " ")
      .trim();
    cleaned = cleaned.replace(/[.\s]+$/g, "").trim();
    if (/^(?:[A-Za-z]\.)+[A-Za-z]$/.test(cleaned)) return cleaned;
    return cleaned.replace(/[.:]+/g, " ").replace(/\s+/g, " ").trim();
  }

  function normalizeShowName(value) {
    return String(value || "")
      .toLowerCase()
      .replace(/&/g, " and ")
      .replace(/['"’]/g, "")
      .replace(/[._:-]+/g, " ")
      .replace(/\b(?:us|uk|au)\b/g, " ")
      .replace(/\b(?:19|20)\d{2}\b/g, " ")
      .replace(/\s+/g, " ")
      .trim();
  }

  function compactShowNameKey(value) {
    return normalizeShowName(value).replace(/[^a-z0-9]+/g, "");
  }

  function sameImportedShow(show, parsed) {
    return compactShowNameKey(show.name) === compactShowNameKey(parsed.name)
      && String(show.targetSeason || "") === String(parsed.targetSeason || "");
  }

  function isGenericShowName(value) {
    const text = normalizeShowName(value);
    return !text
      || text === "watch and download tv series on eztv"
      || text === "eztv torrents"
      || text === "eztv tv torrents online series download official"
      || text.startsWith("eztv tv torrents online series download");
  }

  function cssEscape(value) {
    if (window.CSS && CSS.escape) return CSS.escape(value);
    return String(value).replace(/"/g, '\\"');
  }

  function injectStyles() {
    if (document.getElementById("stw-style")) return;
    const style = document.createElement("style");
    style.id = "stw-style";
    style.textContent = `
      #stw-root {
        font: 13px/1.4 Arial, sans-serif;
        color: #eef5fb;
        margin: 10px 0;
        position: relative;
        z-index: 999999;
      }
      #stw-root * { box-sizing: border-box; }
      #stw-root button,
      #stw-root input,
      #stw-root select,
      #stw-root textarea {
        font: inherit;
      }
      #stw-root button {
        appearance: none;
        border: 1px solid #2d6aa6;
        background: #1e4e7d;
        color: #fff;
        padding: 8px 10px;
        border-radius: 6px;
        cursor: pointer;
        font-weight: 700;
      }
      #stw-root button:hover { background: #265f97; }
      #stw-root input,
      #stw-root select,
      #stw-root textarea {
        width: 100%;
        border: 1px solid #36526e;
        border-radius: 7px;
        background: #0b131c;
        color: #eef5fb;
        padding: 8px;
      }
      #stw-root textarea {
        resize: vertical;
        min-height: 110px;
      }
      #stw-root label {
        display: grid;
        gap: 4px;
        margin: 8px 0;
        color: #c6d8ea;
        font-weight: 700;
      }
      .stw-bar {
        display: flex;
        gap: 8px;
        align-items: center;
        flex-wrap: wrap;
        padding: 8px;
        border: 1px solid #274c70;
        background: #101b27;
      }
      .stw-pill {
        display: inline-flex;
        align-items: center;
        min-height: 30px;
        padding: 0 10px;
        border-radius: 999px;
        background: #20384f;
        color: #d9ecff;
        font-size: 12px;
      }
      .stw-panel {
        width: min(1040px, calc(100vw - 24px));
        max-height: 76vh;
        overflow: auto;
        margin-top: 8px;
        border: 1px solid #35506d;
        background: #0f1823;
        box-shadow: 0 16px 36px rgba(0, 0, 0, 0.45);
      }
      .stw-head,
      .stw-show-row,
      .stw-result,
      .stw-toolbar {
        display: flex;
        justify-content: space-between;
        gap: 10px;
        align-items: center;
      }
      .stw-head {
        position: sticky;
        top: 0;
        padding: 10px 12px;
        background: #122131;
        border-bottom: 1px solid #24384d;
      }
      .stw-head button {
        border-color: #555;
        background: #2c2c2c;
        padding: 4px 8px;
      }
      .stw-status {
        min-height: 18px;
        padding: 10px 12px;
        color: #c6d8ea;
        white-space: pre-wrap;
      }
      .stw-body,
      .stw-result-list {
        display: grid;
        gap: 8px;
      }
      .stw-body {
        padding: 0 12px 12px;
      }
      .stw-section-title {
        padding: 10px 2px 2px;
        color: #d9ecff;
        font-weight: 700;
        font-size: 14px;
      }
      .stw-card,
      .stw-empty,
      .stw-result {
        border: 1px solid #24384d;
        background: #131f2c;
        padding: 10px;
        border-radius: 8px;
      }
      .stw-toolbar {
        justify-content: flex-start;
        flex-wrap: wrap;
      }
      .stw-scan-card {
        display: grid;
        gap: 6px;
      }
      .stw-live-scan {
        max-height: 76px;
        overflow-y: auto;
        border: 1px solid #24384d;
        background: #0b131c;
        border-radius: 7px;
        padding: 7px 9px;
      }
      .stw-live-scan div {
        padding: 2px 0;
      }
      .stw-actions {
        display: flex;
        gap: 6px;
        flex-wrap: wrap;
        justify-content: flex-end;
      }
      .stw-left {
        justify-content: flex-start;
      }
      .stw-check {
        display: flex !important;
        grid-template-columns: none !important;
        flex-direction: row;
        align-items: flex-start;
        gap: 8px !important;
        margin: 0 !important;
      }
      .stw-check input[type="checkbox"] {
        width: 18px !important;
        min-width: 18px;
        margin-top: 2px;
      }
      .stw-muted,
      .stw-title {
        display: block;
        color: #9bb3ca;
        font-size: 12px;
        word-break: break-word;
      }
      .stw-note {
        grid-column: 1 / -1;
        color: #9bb3ca;
        font-size: 12px;
        border-top: 1px solid #24384d;
        padding-top: 8px;
      }
      .stw-form {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 8px 12px;
      }
      .stw-form .stw-actions {
        grid-column: 1 / -1;
      }
      @media (max-width: 760px) {
        .stw-show-row,
        .stw-result {
          align-items: stretch;
          flex-direction: column;
        }
        .stw-actions {
          justify-content: flex-start;
        }
        .stw-form {
          grid-template-columns: 1fr;
        }
      }
    `;
    document.documentElement.appendChild(style);
  }

  function escapeHtml(value) {
    return String(value ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function escapeAttr(value) {
    return escapeHtml(value).replace(/`/g, "&#96;");
  }
})();
