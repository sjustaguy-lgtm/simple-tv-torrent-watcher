Simple TV Torrent Watcher 2.0.7.3 fixes missed episodes caused by older or messy saved show names.

- Re-parses stored watchlist names during scan and season-date checks.
- Repairs entries saved as export lines, season requests, or full release filenames, such as `Futurama | S13E10`, `Futurama season 14`, and `Futurama.S14E01.1080p...`.
- Clears stale skip/status metadata when a stored show name is repaired so already-aired episodes are not hidden by an old pause.
- Keeps exact title matching for RSS/custom feeds and trusted IMDB-based EZTV API matching.
- Existing watchlists and settings remain in browser storage.
