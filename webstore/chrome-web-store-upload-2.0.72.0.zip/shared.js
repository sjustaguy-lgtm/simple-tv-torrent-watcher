(() => {
  function episodeCode(season, episode) {
    return `S${String(Number(season)).padStart(2, "0")}E${String(Number(episode)).padStart(2, "0")}`;
  }

  function parseEpisodeReference(value) {
    const text = String(value || "");
    const patterns = [
      /\bseason\s*(\d{1,4})[.\s_-]*(?:episode|ep|e)[.\s_-]*(\d{1,4})\b/i,
      /\bS(\d{1,4})[.\s_-]*E(\d{1,4})\b/i,
      /\b(\d{1,4})x(\d{1,4})\b/i
    ];
    const matches = patterns.map((pattern) => text.match(pattern)).filter(Boolean);
    const match = matches.sort((a, b) => a.index - b.index)[0];
    return match ? { raw: match[0], index: match.index, season: Number(match[1]), episode: Number(match[2]) } : null;
  }

  function parseCode(value) {
    const match = parseEpisodeReference(value);
    return match ? { code: episodeCode(match.season, match.episode), s: match.season, e: match.episode } : null;
  }

  function normalizeEpisode(value) {
    return parseCode(value)?.code || "";
  }

  function compareCodes(a, b) {
    const left = typeof a === "string" ? parseCode(a) : a;
    const right = typeof b === "string" ? parseCode(b) : b;
    if (!left || !right) return 0;
    return left.s - right.s || left.e - right.e;
  }

  function extractQuality(value) {
    const text = String(value || "");
    const match = text.match(/\b(2160p|1080p|720p|480p)\b/i);
    return match ? match[1].toLowerCase() : (/\b4k\b/i.test(text) ? "2160p" : "");
  }

  function stripTrailingReleaseTags(value) {
    let text = String(value || "");
    for (let i = 0; i < 6; i += 1) {
      const before = text;
      text = text.replace(/[.\s_-]+(?:eztvx(?:\.to)?|eztv(?:\.(?:re|wf|to))?|tgx|megusta)\s*$/i, " ").trim();
      if (text === before) break;
    }
    return text;
  }

  function stripReleaseWords(value) {
    let text = String(value || "").replace(/\[[^\]]*\]/g, " ").replace(/\.(?:mkv|mp4|avi|torrent)\b/ig, " ");
    const marker = text.match(/\b(?:2160p|1080p|720p|480p|4k|x264|x265|h264|h265|hevc|avc|webrip|web-dl|hdtv|bluray)\b/i);
    if (marker && marker.index > 0) text = text.slice(0, marker.index);
    return stripTrailingReleaseTags(text);
  }

  function cleanImportedShowName(value) {
    const text = String(value || "")
      .replace(/&amp;/gi, "&")
      .replace(/\[[^\]]*\]/g, " ")
      .replace(/\.(?:mkv|mp4|avi|torrent)$/i, "")
      .replace(/['"\u2018\u2019]/g, "").trim();
    if (/^(?:[A-Za-z]\.){2,}[A-Za-z]\.?$/.test(text)) return text.replace(/\.$/, "");
    return text.replace(/[_:.-]+/g, " ").replace(/\s+/g, " ").trim();
  }

  function extractSeasonTarget(value) {
    const text = String(value || "");
    const match = text.match(/\b(?:season[.\s_-]*|s)(\d{1,3})\b/i);
    return match ? { name: text.slice(0, match.index), targetSeason: Number(match[1]) } : { name: text, targetSeason: null };
  }

  function parseShowInput(value) {
    const text = String(value || "").trim();
    const preferredQuality = extractQuality(text);
    const exported = text.match(/^(.*?)\s*\|\s*((?:S\d{1,4}E\d{1,4})|(?:\d{1,4}x\d{1,4}))\s*$/i);
    const episode = parseEpisodeReference(exported ? exported[2] : text);
    const prefix = exported ? exported[1] : (episode ? text.slice(0, episode.index) : text);
    const season = extractSeasonTarget(prefix);
    return {
      name: cleanImportedShowName(stripReleaseWords(season.name)),
      lastSeen: episode ? episodeCode(episode.season, episode.episode) : "",
      targetSeason: season.targetSeason || (episode?.episode === 0 ? episode.season : null),
      preferredQuality
    };
  }

  function normalizeShowName(value) {
    return String(value || "").normalize("NFKD").replace(/[\u0300-\u036f]/g, "")
      .toLowerCase().replace(/&(?:amp;)?/g, " and ").replace(/['"\u2018\u2019]/g, "")
      .replace(/[._:()\[\]-]+/g, " ").replace(/\s+/g, " ").trim();
  }

  function compactShowNameKey(value) {
    return normalizeShowName(value).replace(/[^a-z0-9]+/g, "");
  }

  function splitShowTitle(value) {
    let base = normalizeShowName(value);
    let year = "";
    let country = "";
    for (let i = 0; i < 2; i += 1) {
      const qualifier = base.match(/^(.+?)\s+(us|uk|au|ca|nz|(?:19|20)\d{2})$/i);
      if (!qualifier) break;
      if (/^\d{4}$/.test(qualifier[2])) year = qualifier[2];
      else country = qualifier[2];
      base = qualifier[1];
    }
    return { base, baseKey: compactShowNameKey(base), year, country };
  }

  function showTitlePartsMatch(wantedInput, foundInput, trusted = false) {
    const wanted = typeof wantedInput === "string" ? splitShowTitle(wantedInput) : wantedInput;
    const found = typeof foundInput === "string" ? splitShowTitle(foundInput) : foundInput;
    if (!wanted.baseKey || wanted.baseKey !== found.baseKey) return false;
    if (wanted.year !== found.year && !(trusted && wanted.year && !found.year)) return false;
    if (wanted.country !== found.country && !(trusted && wanted.country && !found.country)) return false;
    return true;
  }

  function titleShowName(title) {
    const episode = parseEpisodeReference(title);
    return episode ? cleanImportedShowName(stripReleaseWords(String(title).slice(0, episode.index))) : "";
  }

  function titleMatchesShow(showName, torrentTitle, trusted = false) {
    const candidate = titleShowName(torrentTitle);
    return Boolean(candidate && showTitlePartsMatch(showName, candidate, trusted));
  }

  function extractUploader(title) {
    const text = String(title || "").replace(/\[[^\]]*\]/g, " ").replace(/\.(?:mkv|mp4|avi|torrent)\b/gi, " ").trim();
    const match = text.match(/-([A-Za-z0-9]+)\s*(?:EZTV|TGx)?\s*$/i);
    return match ? match[1] : "Unknown";
  }

  function parseSize(value) {
    if (value == null || value === "") return null;
    if (typeof value === "number" || /^\d+(?:\.\d+)?$/.test(String(value).trim())) {
      const size = Number(value);
      return Number.isFinite(size) && size > 0 ? size : null;
    }
    const match = String(value).match(/([\d.]+)\s*(KiB|MiB|GiB|TiB|KB|MB|GB|TB|bytes?|B)\b/i);
    if (!match) return null;
    const unit = match[2].toLowerCase();
    const power = ({ k: 1, m: 2, g: 3, t: 4 })[unit[0]] || 0;
    const size = Number(match[1]) * (unit.includes("i") ? 1024 : 1000) ** power;
    return Number.isFinite(size) && size > 0 ? size : null;
  }

  function formatSize(value) {
    const size = parseSize(value);
    if (!size) return "size unknown";
    return size >= 1e9 ? `${(size / 1e9).toFixed(2)} GB` : `${(size / 1e6).toFixed(0)} MB`;
  }

  function isGenericShowName(value) {
    const text = normalizeShowName(value);
    return !text || /^(?:eztv|watch and download tv series|the pirate bay|details for|search results)/.test(text);
  }

  function isPendingEpisode(show, item) {
    const floor = show.baselineFloor === undefined ? show.lastSeen : show.baselineFloor;
    return Boolean(parseCode(item.code)
      && (!floor || compareCodes(item.code, floor) > 0)
      && !(show.handledEpisodes || []).includes(item.code));
  }

  globalThis.TVWatcher = {
    episodeCode, parseEpisodeReference, parseCode, normalizeEpisode, compareCodes,
    extractQuality, stripTrailingReleaseTags, stripReleaseWords, cleanImportedShowName,
    extractSeasonTarget, parseShowInput, normalizeShowName, compactShowNameKey,
    splitShowTitle, showTitlePartsMatch, titleShowName, titleMatchesShow, extractUploader,
    parseSize, formatSize, isGenericShowName, isPendingEpisode
  };
})();
