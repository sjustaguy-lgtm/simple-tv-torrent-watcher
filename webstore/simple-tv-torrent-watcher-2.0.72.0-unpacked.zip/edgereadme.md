# Edge Installation

1. Extract this ZIP to a permanent folder.
2. Open edge://extensions.
3. Enable Developer mode.
4. Click Load unpacked and choose ARC_BRAVE_CHROME_EDGE_OPERA_VIVALDI_LOAD_UNPACKED.
5. Keep that folder in place.

To update an existing copy, replace its files in the same folder and click Reload. Do not remove the extension; existing browser storage is preserved. Refresh EZTV/Pirate Bay tabs.

Enable Pirate Bay in the extension Settings and click Save to approve its optional access.

A normal store installation uses the Chrome Web Store listing; this ZIP is for unpacked testing and sharing.
