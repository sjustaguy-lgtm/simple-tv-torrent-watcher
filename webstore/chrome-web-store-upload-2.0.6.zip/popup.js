const DEFAULT_SETTINGS = {
  delivery: "qbit",
  torrentClient: "qbit",
  qbitHost: "http://localhost:8080",
  qbitUser: "",
  qbitPass: "",
  qbitCategory: "tv",
  preferredQualities: ["1080p", "720p"],
  preferredUploaders: ["MeGusta", "TGx", "EZTV"],
  rssSources: [],
  minSeeders: 0,
  autoCheckMinutes: 0
};

const $ = (id) => document.getElementById(id);

document.addEventListener("DOMContentLoaded", async () => {
  bindTabs();
  $("addShow").addEventListener("click", addShow);
  $("scanAll").addEventListener("click", scanAll);
  $("checkSeasonDates").addEventListener("click", checkSeasonDates);
  $("saveSettings").addEventListener("click", saveSettings);
  $("testQbit").addEventListener("click", testQbit);
  $("useLocalhost").addEventListener("click", useLocalhostHost);
  $("useIpHost").addEventListener("click", useDirectIpHost);

  const [active] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (active?.url && /eztv/i.test(active.url)) {
    try {
      const result = await chrome.tabs.sendMessage(active.id, { type: "get-show-context" });
      if (result?.name && !isGenericShowName(result.name)) {
        $("showName").value = result.name;
        $("imdbId").value = result.imdbId || "";
      }
    } catch {}
  }

  await loadSettings();
  await renderShows();
  openInitialTab();
});

function bindTabs() {
  document.querySelectorAll("nav button").forEach((button) => {
    button.addEventListener("click", () => {
      document.querySelectorAll("nav button").forEach((item) => item.classList.remove("active"));
      document.querySelectorAll("section").forEach((item) => item.classList.remove("active"));
      button.classList.add("active");
      $(button.dataset.tab).classList.add("active");
    });
  });
}

function openInitialTab() {
  const tab = String(location.hash || "").replace(/^#/, "");
  if (!["shows", "add", "settings"].includes(tab)) return;
  document.querySelector(`nav button[data-tab="${tab}"]`)?.click();
}

async function loadSettings() {
  const { settings = DEFAULT_SETTINGS } = await chrome.storage.local.get("settings");
  const merged = { ...DEFAULT_SETTINGS, ...settings };
  $("delivery").value = merged.delivery;
  $("torrentClient").value = merged.torrentClient || "qbit";
  $("qbitHost").value = merged.qbitHost;
  $("qbitUser").value = merged.qbitUser;
  $("qbitPass").value = merged.qbitPass;
  $("qbitCategory").value = merged.qbitCategory;
  $("preferredQualities").value = asText(merged.preferredQualities);
  $("preferredUploaders").value = asText(merged.preferredUploaders);
  $("rssSources").value = rssSourcesToText(merged.rssSources);
  $("minSeeders").value = merged.minSeeders;
  $("autoCheckMinutes").value = merged.autoCheckMinutes;
}

async function saveSettings() {
  const settings = {
    delivery: $("delivery").value,
    torrentClient: $("torrentClient").value,
    qbitHost: $("qbitHost").value.trim(),
    qbitUser: $("qbitUser").value.trim(),
    qbitPass: $("qbitPass").value,
    qbitCategory: $("qbitCategory").value.trim(),
    preferredQualities: $("preferredQualities").value,
    preferredUploaders: $("preferredUploaders").value,
    rssSources: parseRssSources($("rssSources").value),
    minSeeders: Number($("minSeeders").value) || 0,
    autoCheckMinutes: Number($("autoCheckMinutes").value) || 0
  };
  const granted = await ensureTorrentClientPermission(settings);
  if (!granted.ok) {
    setStatus(granted.error);
    return false;
  }
  const response = await send({ type: "save-settings", settings });
  setStatus(response.ok ? "Saved." : response.error);
  return Boolean(response.ok);
}

async function ensureTorrentClientPermission(settings) {
  const origins = [];
  if (settings.delivery !== "magnet") {
    const origin = permissionOrigin(settings.qbitHost);
    if (!origin) return { ok: false, error: "Enter a valid WebUI URL before saving." };
    origins.push(origin);
  }
  for (const source of settings.rssSources || []) {
    const origin = permissionOrigin(source.url);
    if (!origin) return { ok: false, error: `Check this RSS feed URL: ${source.url}` };
    origins.push(origin);
  }
  const needed = [...new Set(origins)].filter((origin) => !isBuiltInOrigin(origin));
  if (!needed.length) return { ok: true };
  try {
    const granted = await chrome.permissions.request({ origins: needed });
    return granted
      ? { ok: true }
      : { ok: false, error: "Permission was not granted. The extension needs access to the WebUI/RSS address you entered." };
  } catch (error) {
    return { ok: false, error: error.message || "The browser blocked the permission request. Click Save or Test Client from the extension popup and approve the prompt." };
  }
}

function permissionOrigin(value) {
  try {
    const url = new URL(value);
    if (!/^https?:$/.test(url.protocol)) return "";
    return `${url.protocol}//${url.host}/*`;
  } catch {
    return "";
  }
}

function isBuiltInOrigin(origin) {
  return [
    "http://localhost/*",
    "http://127.0.0.1/*",
    "https://api.tvmaze.com/*",
    "https://eztvx.to/*",
    "https://eztv.re/*",
    "https://eztv.wf/*",
    "https://eztv.ag/*",
    "https://eztv.it/*",
    "https://eztv.ch/*",
    "https://eztv.li/*"
  ].includes(origin);
}

async function testQbit() {
  setStatus("Testing torrent client...");
  const saved = await saveSettings();
  if (!saved) return;
  const response = await send({ type: "qbit-test" });
  setStatus(response.ok ? `Torrent client connected: ${response.version}` : response.error);
}

function useLocalhostHost() {
  $("qbitHost").value = defaultHostForClient($("torrentClient").value, "localhost");
  setStatus("Set host to localhost. Use this only when the torrent client is on this same computer.");
}

function useDirectIpHost() {
  const port = portFromHost($("qbitHost").value) || portForClient($("torrentClient").value);
  const ip = prompt("Enter the WebUI computer IP address", "192.168.1.50");
  if (!ip) return;
  const cleanIp = ip.replace(/^https?:\/\//i, "").replace(/\/.*$/, "").replace(/:\d+$/, "").trim();
  $("qbitHost").value = `http://${cleanIp}:${port}`;
  setStatus("Set host to direct IP. Click Test Client to confirm it connects.");
}

function defaultHostForClient(client, host) {
  if (client === "transmission") return `http://${host}:9091`;
  if (client === "deluge") return `http://${host}:8112`;
  if (client === "aria2") return `http://${host}:6800/jsonrpc`;
  return `http://${host}:8080`;
}

function portForClient(client) {
  if (client === "transmission") return "9091";
  if (client === "deluge") return "8112";
  if (client === "aria2") return "6800";
  return "8080";
}

function portFromHost(value) {
  const match = String(value || "").match(/:(\d+)(?:\/|$)/);
  return match ? match[1] : "";
}

async function addShow() {
  const show = {
    name: $("showName").value,
    imdbId: $("imdbId").value,
    lastSeen: $("lastSeen").value
  };
  const response = await send({ type: "add-show", show });
  if (!response.ok) {
    setStatus(response.error);
    return;
  }
  $("showName").value = "";
  $("imdbId").value = "";
  $("lastSeen").value = "";
  setStatus("Show added.");
  await renderShows();
  document.querySelector('[data-tab="shows"]').click();
}

async function scanAll() {
  setStatus("Checking shows...");
  await send({ type: "maybe-check-season-dates" });
  const response = await send({ type: "scan-all" });
  if (!response.ok) {
    setStatus(response.error);
    return;
  }
  const errorText = response.errors?.length ? `\n${response.errors.join("\n")}` : "";
  setStatus(`Checked ${response.checked}. Found ${response.found}.${errorText}`);
  await renderShows();
}

async function checkSeasonDates() {
  setStatus("Checking upcoming season dates...");
  const response = await send({ type: "check-season-dates" });
  if (!response.ok) {
    setStatus(response.error || "Could not check season dates.");
    return;
  }
  setStatus(`Checked ${response.checked || 0}. Updated ${response.updated || 0}. Cleared ${response.cleared || 0}. Ended/canceled: ${response.endedShows?.length || 0}.`);
  await renderShows();
}

async function renderShows() {
  const { shows = [] } = await chrome.storage.local.get("shows");
  const root = $("showList");
  if (!shows.length) {
    root.innerHTML = '<div class="card muted">No shows yet.</div>';
    return;
  }
  const sorted = [...shows].sort((a, b) => normalizeShowName(a.name).localeCompare(normalizeShowName(b.name)));
  const searching = sorted.filter((show) => !isPausedShow(show) && !isEndedShow(show));
  const paused = sorted.filter((show) => isPausedShow(show) || isEndedShow(show));
  root.innerHTML = `
    <div class="section-title">Searching Now (${searching.length})</div>
    ${searching.length ? searching.map(renderShowCard).join("") : '<div class="card muted">No shows are currently searching.</div>'}
    <div class="section-title">Paused / Ended (${paused.length})</div>
    ${paused.length ? paused.map(renderShowCard).join("") : '<div class="card muted">No shows are paused.</div>'}
  `;
  root.querySelectorAll("[data-remove]").forEach((button) => {
    button.addEventListener("click", async () => {
      await send({ type: "remove-show", id: button.dataset.remove });
      await renderShows();
    });
  });
  root.querySelectorAll("[data-send-magnet]").forEach((button) => {
    button.addEventListener("click", async () => {
      const response = await send({ type: "send-magnets", items: [{
        showId: button.dataset.sendShow,
        code: button.dataset.sendCode,
        magnet: button.dataset.sendMagnet,
        title: button.dataset.sendTitle
      }] });
      const errors = response.errors?.length ? ` Errors: ${response.errors.join(" | ")}` : "";
      setStatus(`Sent ${response.sent || 0}.${errors}`);
      await renderShows();
    });
  });
  root.querySelectorAll("[data-have-show]").forEach((button) => {
    button.addEventListener("click", async () => {
      const response = await send({ type: "mark-seen", id: button.dataset.haveShow, code: button.dataset.haveCode });
      setStatus(response.ok ? `Marked ${button.dataset.haveCode} as already downloaded.` : response.error);
      await renderShows();
    });
  });
}

function renderShowCard(show) {
  const ended = isEndedShow(show);
  const stateText = ended
    ? ` · Status: ${escapeHtml(show.seriesStatus)}`
    : (show.skipUntil ? ` · Paused until ${escapeHtml(show.skipUntil)}` : "");
  return `
    <div class="card">
      <strong>${escapeHtml(show.name)}</strong>
      <div class="muted">Last: ${escapeHtml(show.lastSeen || "not set")}${show.preferredQuality ? ` · Quality ${escapeHtml(show.preferredQuality)}` : ""} · IMDB: ${escapeHtml(show.imdbId ? `tt${show.imdbId}` : "auto")}${stateText}</div>
      <div class="toolbar">
        <button data-remove="${show.id}" class="danger">${ended ? "Remove Ended Show" : "Remove"}</button>
      </div>
      <div class="results">
        ${(show.results || []).filter((item) => !show.lastSeen || compareCodes(item.code, show.lastSeen) > 0).slice(0, 5).map((item) => `
          <div class="result">
            <div><strong>${escapeHtml(item.code)}</strong> ${escapeHtml(item.quality || "")} ${escapeHtml(item.uploader || "")} · ${Number(item.seeds || 0)} seeds</div>
            <button data-send-show="${escapeAttr(show.id)}" data-send-code="${escapeAttr(item.code)}" data-send-title="${escapeAttr(item.title || item.code)}" data-send-magnet="${escapeAttr(item.magnet)}">Send</button>
            <button data-have-show="${escapeAttr(show.id)}" data-have-code="${escapeAttr(item.code)}">I already have this episode</button>
          </div>
        `).join("")}
      </div>
    </div>
  `;
}

function isPausedShow(show) {
  return Boolean(show.skipUntil && show.skipUntil > new Date().toISOString().slice(0, 10));
}

function isEndedShow(show) {
  return /ended|cancelled|canceled/i.test(String(show.seriesStatus || ""));
}

function send(message) {
  return chrome.runtime.sendMessage(message);
}

function setStatus(text) {
  $("status").textContent = text || "";
}

function asText(value) {
  return Array.isArray(value) ? value.join(", ") : String(value || "");
}

function parseRssSources(text) {
  return String(text || "")
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => {
      const parts = line.split(/\s*\|\s*/);
      const maybeUrl = parts.length > 1 ? parts.pop() : line;
      let host = "RSS Feed";
      try { host = new URL(maybeUrl).host || host; } catch {}
      return {
        name: parts.join(" | ").trim() || host,
        url: maybeUrl.trim()
      };
    });
}

function rssSourcesToText(value) {
  return (Array.isArray(value) ? value : [])
    .map((source) => `${source.name || "RSS Feed"} | ${source.url || ""}`.trim())
    .filter((line) => line && !line.endsWith("|"))
    .join("\n");
}

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function escapeAttr(value) {
  return escapeHtml(value).replace(/`/g, "&#96;");
}

function parseCode(value) {
  const match = String(value || "").match(/S(\d{1,4})E(\d{1,4})/i);
  return match ? { s: Number(match[1]), e: Number(match[2]) } : null;
}

function compareCodes(a, b) {
  const left = parseCode(a);
  const right = parseCode(b);
  if (!left || !right) return 0;
  if (left.s !== right.s) return left.s - right.s;
  return left.e - right.e;
}

function normalizeShowName(value) {
  return String(value || "")
    .toLowerCase()
    .replace(/&/g, " and ")
    .replace(/['"’]/g, "")
    .replace(/[._:-]+/g, " ")
    .replace(/\b(?:us|uk|au)\b/g, " ")
    .replace(/\b(?:19|20)\d{2}\b/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function isGenericShowName(value) {
  const text = normalizeShowName(value);
  return !text
    || text === "watch and download tv series on eztv"
    || text === "eztv torrents"
    || text === "eztv tv torrents online series download official"
    || text.startsWith("eztv tv torrents online series download");
}
